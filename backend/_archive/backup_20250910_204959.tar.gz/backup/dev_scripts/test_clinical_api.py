#!/usr/bin/env python3
"""
临床场景API测试脚本
测试向量搜索API的临床场景匹配功能
"""
import requests
import json
import time
from typing import List, Dict, Any

class ClinicalAPITester:
    """临床API测试器"""
    
    def __init__(self, base_url: str = "http://localhost:8000"):
        self.base_url = base_url
        self.session = requests.Session()
    
    def test_clinical_scenarios(self):
        """测试临床场景案例"""
        print("🏥 测试临床场景案例...")
        
        clinical_cases = [
            {
                "case": "45岁女性，慢性反复头痛3年，无神经系统异常体征。",
                "expected_keywords": ["头痛", "女性", "慢性", "神经"]
            },
            {
                "case": "32岁男性，10分钟前突发剧烈雷击样头痛，无神经系统体征。",
                "expected_keywords": ["头痛", "男性", "突发", "雷击样"]
            },
            {
                "case": "50岁女性，3天前开始出现左侧肢体无力，伴新发头痛。",
                "expected_keywords": ["肢体无力", "女性", "头痛", "左侧"]
            },
            {
                "case": "70岁男性，一周内头痛模式明显改变，原有镇痛药无效。",
                "expected_keywords": ["头痛", "男性", "老年", "模式改变"]
            },
            {
                "case": "55岁男性，新发头痛，伴发热和颈部僵硬。",
                "expected_keywords": ["头痛", "男性", "发热", "颈部僵硬"]
            }
        ]
        
        for i, case_data in enumerate(clinical_cases, 1):
            print(f"\n📋 案例 {i}: {case_data['case']}")
            self._test_single_case(case_data)
    
    def _test_single_case(self, case_data: Dict[str, Any]):
        """测试单个案例"""
        case = case_data["case"]
        expected_keywords = case_data["expected_keywords"]
        
        # 测试场景搜索
        scenarios = self._search_scenarios(case)
        if scenarios:
            print(f"  ✅ 找到 {len(scenarios)} 个相关场景")
            for j, scenario in enumerate(scenarios[:3], 1):
                print(f"    {j}. 相似度: {scenario['similarity_score']:.4f}")
                print(f"       描述: {scenario['description_zh'][:100]}...")
                print(f"       科室: {scenario['panel_name']}")
                print(f"       主题: {scenario['topic_name']}")
        else:
            print("  ❌ 未找到相关场景")
        
        # 测试推荐搜索
        recommendations = self._search_recommendations(case)
        if recommendations:
            print(f"  ✅ 找到 {len(recommendations)} 个相关推荐")
            for j, rec in enumerate(recommendations[:3], 1):
                print(f"    {j}. 相似度: {rec['similarity_score']:.4f}")
                print(f"       检查项目: {rec['procedure_name']}")
                print(f"       适宜性: {rec['appropriateness_category_zh']} ({rec['appropriateness_rating']})")
                print(f"       科室: {rec['panel_name']}")
        else:
            print("  ❌ 未找到相关推荐")
    
    def _search_scenarios(self, query: str) -> List[Dict[str, Any]]:
        """搜索临床场景"""
        try:
            payload = {
                "query_text": query,
                "top_k": 5,
                "similarity_threshold": 0.0
            }
            
            response = self.session.post(
                f"{self.base_url}/api/v1/acrac/vector/v2/search/scenarios",
                json=payload
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                print(f"    ❌ 场景搜索失败: {response.status_code}")
                return []
        except Exception as e:
            print(f"    ❌ 场景搜索错误: {e}")
            return []
    
    def _search_recommendations(self, query: str) -> List[Dict[str, Any]]:
        """搜索临床推荐"""
        try:
            payload = {
                "query_text": query,
                "top_k": 5,
                "similarity_threshold": 0.0
            }
            
            response = self.session.post(
                f"{self.base_url}/api/v1/acrac/vector/v2/search/recommendations",
                json=payload
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                print(f"    ❌ 推荐搜索失败: {response.status_code}")
                return []
        except Exception as e:
            print(f"    ❌ 推荐搜索错误: {e}")
            return []
    
    def test_performance_benchmark(self):
        """性能基准测试"""
        print("\n⚡ 性能基准测试...")
        
        test_queries = [
            "胸部CT检查",
            "心脏MRI扫描",
            "孕妇影像检查",
            "头痛诊断",
            "肿瘤筛查"
        ]
        
        total_time = 0
        successful_requests = 0
        
        for query in test_queries:
            start_time = time.time()
            try:
                payload = {
                    "query_text": query,
                    "top_k": 10,
                    "similarity_threshold": 0.0
                }
                
                response = self.session.post(
                    f"{self.base_url}/api/v1/acrac/vector/v2/search/comprehensive",
                    json=payload
                )
                
                end_time = time.time()
                request_time = end_time - start_time
                
                if response.status_code == 200:
                    result = response.json()
                    print(f"  ✅ '{query}': {request_time*1000:.2f}ms, {result['total_results']}个结果")
                    total_time += request_time
                    successful_requests += 1
                else:
                    print(f"  ❌ '{query}': {response.status_code}")
            except Exception as e:
                print(f"  ❌ '{query}': {e}")
        
        if successful_requests > 0:
            avg_time = total_time / successful_requests
            print(f"\n📊 平均响应时间: {avg_time*1000:.2f}ms")
            print(f"📊 成功率: {successful_requests}/{len(test_queries)} ({successful_requests/len(test_queries)*100:.1f}%)")
    
    def test_api_validation(self):
        """API参数验证测试"""
        print("\n🔍 API参数验证测试...")
        
        # 测试空查询
        try:
            payload = {"query_text": "", "top_k": 5}
            response = self.session.post(
                f"{self.base_url}/api/v1/acrac/vector/v2/search/scenarios",
                json=payload
            )
            print(f"  空查询: {response.status_code} (期望: 422)")
        except Exception as e:
            print(f"  空查询: {e}")
        
        # 测试过长查询
        try:
            long_query = "测试" * 1000
            payload = {"query_text": long_query, "top_k": 5}
            response = self.session.post(
                f"{self.base_url}/api/v1/acrac/vector/v2/search/scenarios",
                json=payload
            )
            print(f"  过长查询: {response.status_code} (期望: 422)")
        except Exception as e:
            print(f"  过长查询: {e}")
        
        # 测试无效top_k
        try:
            payload = {"query_text": "测试", "top_k": 100}
            response = self.session.post(
                f"{self.base_url}/api/v1/acrac/vector/v2/search/scenarios",
                json=payload
            )
            print(f"  无效top_k: {response.status_code} (期望: 422)")
        except Exception as e:
            print(f"  无效top_k: {e}")
        
        # 测试无效相似度阈值
        try:
            payload = {"query_text": "测试", "top_k": 5, "similarity_threshold": 2.0}
            response = self.session.post(
                f"{self.base_url}/api/v1/acrac/vector/v2/search/scenarios",
                json=payload
            )
            print(f"  无效相似度阈值: {response.status_code} (期望: 422)")
        except Exception as e:
            print(f"  无效相似度阈值: {e}")
    
    def run_all_tests(self):
        """运行所有测试"""
        print("🚀 开始临床API测试")
        print("=" * 60)
        
        # 检查服务是否运行
        try:
            response = self.session.get(f"{self.base_url}/health")
            if response.status_code != 200:
                print("❌ 服务未运行，请先启动FastAPI服务")
                return
        except Exception as e:
            print(f"❌ 无法连接到服务: {e}")
            return
        
        # 运行测试
        self.test_clinical_scenarios()
        self.test_performance_benchmark()
        self.test_api_validation()
        
        print("\n✅ 临床API测试完成！")

def main():
    """主函数"""
    tester = ClinicalAPITester()
    tester.run_all_tests()

if __name__ == "__main__":
    main()
