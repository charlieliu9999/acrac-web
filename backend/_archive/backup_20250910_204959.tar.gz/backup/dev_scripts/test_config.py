"""
测试配置文件
"""
import os
from typing import Dict, Any

# 测试配置
TEST_CONFIG = {
    "api_base_url": "http://localhost:8001",
    "database_url": "postgresql://postgres:password@localhost:5432/acrac_db",
    "timeout": 30,
    "max_retries": 3,
    "test_queries": [
        "45岁女性，慢性反复头痛3年",
        "突发剧烈头痛",
        "胸痛伴气促",
        "腹痛伴发热",
        "关节疼痛肿胀",
        "咳嗽咳痰2周",
        "心悸胸闷",
        "腰痛放射到腿部",
        "乳腺肿块",
        "颈部淋巴结肿大"
    ],
    "expected_similarity_threshold": 0.3,
    "min_results_per_query": 1,
    "max_results_per_query": 50
}

# API端点配置
API_ENDPOINTS = {
    "health_check": "/health",
    "vector_search_v1": {
        "scenarios": "/api/v1/acrac/vector/search-scenarios",
        "recommendations": "/api/v1/acrac/vector/search-recommendations"
    },
    "vector_search_v2": {
        "comprehensive": "/api/v1/acrac/vector/v2/search/comprehensive",
        "panels": "/api/v1/acrac/vector/v2/search/panels",
        "topics": "/api/v1/acrac/vector/v2/search/topics",
        "scenarios": "/api/v1/acrac/vector/v2/search/scenarios",
        "procedures": "/api/v1/acrac/vector/v2/search/procedures",
        "recommendations": "/api/v1/acrac/vector/v2/search/recommendations",
        "stats": "/api/v1/acrac/vector/v2/stats"
    },
    "acrac_simple": {
        "search": "/api/v1/acrac/search",
        "recommend": "/api/v1/acrac/recommend",
        "analyze": "/api/v1/acrac/analyze"
    },
    "intelligent_analysis": {
        "analyze": "/api/v1/acrac/intelligent/analyze",
        "recommend": "/api/v1/acrac/intelligent/recommend"
    },
    "three_methods": {
        "recommend": "/api/v1/acrac/methods/recommend",
        "compare": "/api/v1/acrac/methods/compare"
    }
}

# 测试数据验证配置
VALIDATION_CONFIG = {
    "required_fields": {
        "panel": ["id", "semantic_id", "name_zh", "similarity_score"],
        "topic": ["id", "semantic_id", "name_zh", "panel_name", "similarity_score"],
        "scenario": ["id", "semantic_id", "description_zh", "similarity_score"],
        "procedure": ["id", "semantic_id", "name_zh", "similarity_score"],
        "recommendation": ["id", "semantic_id", "similarity_score"]
    },
    "score_ranges": {
        "similarity_score": (0.0, 1.0),
        "appropriateness_rating": (1, 9)
    }
}

def get_test_config() -> Dict[str, Any]:
    """获取测试配置"""
    return TEST_CONFIG

def get_api_endpoints() -> Dict[str, Any]:
    """获取API端点配置"""
    return API_ENDPOINTS

def get_validation_config() -> Dict[str, Any]:
    """获取验证配置"""
    return VALIDATION_CONFIG