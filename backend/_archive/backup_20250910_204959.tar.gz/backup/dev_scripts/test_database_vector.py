"""
数据库连接和向量搜索功能测试

直接测试数据库连接和向量搜索的底层功能：
1. 数据库连接测试
2. 向量嵌入生成测试
3. 向量相似度搜索测试
4. 数据完整性测试
"""

import os
import sys
import time
import logging
from typing import List, Dict, Any, Optional
import asyncio
import psycopg2
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker

# 添加项目根目录到path
sys.path.append('/Users/charlieliu/git_project_vscode/09_medical/ACRAC-web/backend')

from app.core.config import settings
from app.core.database import get_db
from app.services.vector_search_service import VectorSearchService, SiliconFlowEmbedder

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DatabaseVectorTester:
    """数据库向量测试器"""
    
    def __init__(self):
        self.engine = None
        self.SessionLocal = None
        self.embedder = SiliconFlowEmbedder()
        self.test_queries = [
            "45岁女性，慢性反复头痛3年",
            "突发剧烈头痛",
            "胸痛伴气促",
            "腹痛伴发热",
            "关节疼痛肿胀"
        ]
    
    def connect_database(self) -> bool:
        """连接数据库"""
        try:
            logger.info("正在连接数据库...")
            self.engine = create_engine(settings.DATABASE_URL)
            self.SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=self.engine)
            
            # 测试连接
            with self.engine.connect() as conn:
                result = conn.execute(text("SELECT 1"))
                logger.info("✅ 数据库连接成功")
                return True
                
        except Exception as e:
            logger.error(f"❌ 数据库连接失败: {str(e)}")
            return False
    
    def test_pgvector_extension(self) -> Dict[str, Any]:
        """测试pgvector扩展"""
        logger.info("测试pgvector扩展...")
        
        try:
            with self.engine.connect() as conn:
                # 检查pgvector扩展
                result = conn.execute(text("SELECT * FROM pg_extension WHERE extname = 'vector'"))
                extensions = result.fetchall()
                
                if extensions:
                    logger.info("✅ pgvector扩展已安装")
                    
                    # 测试向量操作
                    test_vector = "[1,2,3]"
                    result = conn.execute(text(f"SELECT '{test_vector}'::vector"))
                    logger.info("✅ 向量类型支持正常")
                    
                    return {
                        "pgvector_installed": True,
                        "vector_support": True,
                        "error": None
                    }
                else:
                    logger.error("❌ pgvector扩展未安装")
                    return {
                        "pgvector_installed": False,
                        "vector_support": False,
                        "error": "pgvector extension not installed"
                    }
                    
        except Exception as e:
            logger.error(f"❌ pgvector测试失败: {str(e)}")
            return {
                "pgvector_installed": False,
                "vector_support": False,
                "error": str(e)
            }
    
    def test_data_integrity(self) -> Dict[str, Any]:
        """测试数据完整性"""
        logger.info("测试数据完整性...")
        
        try:
            with self.engine.connect() as conn:
                # 检查各表的记录数
                tables = [
                    "panels",
                    "topics", 
                    "clinical_scenarios",
                    "procedure_dictionary",
                    "clinical_recommendations"
                ]
                
                table_stats = {}
                total_records = 0
                
                for table in tables:
                    # 总记录数
                    result = conn.execute(text(f"SELECT COUNT(*) FROM {table}"))
                    total_count = result.scalar()
                    
                    # 有向量的记录数
                    result = conn.execute(text(f"SELECT COUNT(*) FROM {table} WHERE embedding IS NOT NULL"))
                    vector_count = result.scalar()
                    
                    # 向量覆盖率
                    coverage = (vector_count / total_count * 100) if total_count > 0 else 0
                    
                    table_stats[table] = {
                        "total_records": total_count,
                        "vector_records": vector_count,
                        "vector_coverage": round(coverage, 2)
                    }
                    
                    total_records += total_count
                    
                    logger.info(f"  {table}: {total_count}条记录, {vector_count}条有向量 ({coverage:.1f}%)")
                
                logger.info(f"✅ 数据完整性检查完成，总计 {total_records} 条记录")
                
                return {
                    "total_records": total_records,
                    "table_stats": table_stats,
                    "data_integrity": True,
                    "error": None
                }
                
        except Exception as e:
            logger.error(f"❌ 数据完整性测试失败: {str(e)}")
            return {
                "total_records": 0,
                "table_stats": {},
                "data_integrity": False,
                "error": str(e)
            }
    
    def test_embedding_generation(self) -> Dict[str, Any]:
        """测试向量嵌入生成"""
        logger.info("测试向量嵌入生成...")
        
        test_text = "45岁女性，慢性反复头痛3年"
        results = []
        
        try:
            start_time = time.time()
            embedding = self.embedder.generate_embedding(test_text)
            generation_time = (time.time() - start_time) * 1000
            
            if embedding and len(embedding) == 1024:
                logger.info(f"✅ 向量生成成功 - 维度: {len(embedding)}, 耗时: {generation_time:.2f}ms")
                
                # 检查向量值的合理性
                avg_value = sum(embedding) / len(embedding)
                max_value = max(embedding)
                min_value = min(embedding)
                
                return {
                    "success": True,
                    "dimension": len(embedding),
                    "generation_time_ms": round(generation_time, 2),
                    "avg_value": round(avg_value, 6),
                    "max_value": round(max_value, 6),
                    "min_value": round(min_value, 6),
                    "error": None
                }
            else:
                logger.error(f"❌ 向量生成失败 - 维度错误: {len(embedding) if embedding else 0}")
                return {
                    "success": False,
                    "dimension": len(embedding) if embedding else 0,
                    "generation_time_ms": round(generation_time, 2),
                    "error": "Invalid embedding dimension"
                }
                
        except Exception as e:
            logger.error(f"❌ 向量生成异常: {str(e)}")
            return {
                "success": False,
                "dimension": 0,
                "generation_time_ms": 0,
                "error": str(e)
            }
    
    def test_vector_search_direct(self) -> Dict[str, Any]:
        """直接测试向量搜索"""
        logger.info("测试直接向量搜索...")
        
        results = []
        
        try:
            db = next(get_db())
            service = VectorSearchService(db)
            
            for query in self.test_queries:
                logger.info(f"  测试查询: {query}")
                
                start_time = time.time()
                
                # 测试各实体类型搜索
                try:
                    panels = service.search_panels(query, top_k=5)
                    topics = service.search_topics(query, top_k=5)
                    scenarios = service.search_scenarios(query, top_k=5)
                    procedures = service.search_procedures(query, top_k=5)
                    recommendations = service.search_recommendations(query, top_k=5)
                    
                    search_time = (time.time() - start_time) * 1000
                    
                    result = {
                        "query": query,
                        "search_time_ms": round(search_time, 2),
                        "results": {
                            "panels": len(panels),
                            "topics": len(topics),
                            "scenarios": len(scenarios),
                            "procedures": len(procedures),
                            "recommendations": len(recommendations)
                        },
                        "total_results": len(panels) + len(topics) + len(scenarios) + len(procedures) + len(recommendations),
                        "success": True,
                        "error": None
                    }
                    
                    # 检查相似度分数
                    if recommendations:
                        top_similarity = recommendations[0].get("similarity_score", 0)
                        result["top_similarity"] = round(top_similarity, 4)
                        
                        logger.info(f"    找到 {result['total_results']} 条结果, 最高相似度: {top_similarity:.4f}, 耗时: {search_time:.2f}ms")
                    else:
                        logger.warning(f"    未找到推荐结果")
                    
                    results.append(result)
                    
                except Exception as e:
                    logger.error(f"    搜索失败: {str(e)}")
                    results.append({
                        "query": query,
                        "search_time_ms": 0,
                        "results": {},
                        "total_results": 0,
                        "success": False,
                        "error": str(e)
                    })
            
            db.close()
            
            # 统计结果
            successful_searches = [r for r in results if r["success"]]
            total_results = sum(r["total_results"] for r in successful_searches)
            avg_search_time = sum(r["search_time_ms"] for r in successful_searches) / len(successful_searches) if successful_searches else 0
            
            logger.info(f"✅ 向量搜索测试完成:")
            logger.info(f"  成功查询: {len(successful_searches)}/{len(results)}")
            logger.info(f"  总结果数: {total_results}")
            logger.info(f"  平均搜索时间: {avg_search_time:.2f}ms")
            
            return {
                "total_queries": len(results),
                "successful_queries": len(successful_searches),
                "total_results": total_results,
                "avg_search_time_ms": round(avg_search_time, 2),
                "query_results": results,
                "overall_success": len(successful_searches) == len(results)
            }
            
        except Exception as e:
            logger.error(f"❌ 向量搜索测试异常: {str(e)}")
            return {
                "total_queries": 0,
                "successful_queries": 0,
                "total_results": 0,
                "avg_search_time_ms": 0,
                "query_results": [],
                "overall_success": False,
                "error": str(e)
            }
    
    def test_vector_similarity_accuracy(self) -> Dict[str, Any]:
        """测试向量相似度准确性"""
        logger.info("测试向量相似度准确性...")
        
        # 测试相似查询
        similar_queries = [
            ("头痛", "头疼"),
            ("胸痛", "胸部疼痛"),
            ("腹痛", "肚子痛"),
            ("咳嗽", "咳嗽咳痰")
        ]
        
        # 测试不相似查询
        dissimilar_queries = [
            ("头痛", "脚痛"),
            ("胸痛", "眼睛疼"),
            ("腹痛", "耳鸣"),
            ("咳嗽", "便秘")
        ]
        
        results = {
            "similar_pairs": [],
            "dissimilar_pairs": [],
            "accuracy_metrics": {}
        }
        
        try:
            # 测试相似查询对
            for query1, query2 in similar_queries:
                embedding1 = self.embedder.generate_embedding(query1)
                embedding2 = self.embedder.generate_embedding(query2)
                
                if embedding1 and embedding2:
                    # 计算余弦相似度
                    import numpy as np
                    
                    vec1 = np.array(embedding1)
                    vec2 = np.array(embedding2)
                    
                    cosine_similarity = np.dot(vec1, vec2) / (np.linalg.norm(vec1) * np.linalg.norm(vec2))
                    
                    results["similar_pairs"].append({
                        "query1": query1,
                        "query2": query2,
                        "similarity": round(float(cosine_similarity), 4)
                    })
                    
                    logger.info(f"  相似查询 '{query1}' vs '{query2}': {cosine_similarity:.4f}")
            
            # 测试不相似查询对
            for query1, query2 in dissimilar_queries:
                embedding1 = self.embedder.generate_embedding(query1)
                embedding2 = self.embedder.generate_embedding(query2)
                
                if embedding1 and embedding2:
                    vec1 = np.array(embedding1)
                    vec2 = np.array(embedding2)
                    
                    cosine_similarity = np.dot(vec1, vec2) / (np.linalg.norm(vec1) * np.linalg.norm(vec2))
                    
                    results["dissimilar_pairs"].append({
                        "query1": query1,
                        "query2": query2,
                        "similarity": round(float(cosine_similarity), 4)
                    })
                    
                    logger.info(f"  不相似查询 '{query1}' vs '{query2}': {cosine_similarity:.4f}")
            
            # 计算准确性指标
            similar_scores = [p["similarity"] for p in results["similar_pairs"]]
            dissimilar_scores = [p["similarity"] for p in results["dissimilar_pairs"]]
            
            if similar_scores and dissimilar_scores:
                avg_similar = sum(similar_scores) / len(similar_scores)
                avg_dissimilar = sum(dissimilar_scores) / len(dissimilar_scores)
                
                results["accuracy_metrics"] = {
                    "avg_similar_score": round(avg_similar, 4),
                    "avg_dissimilar_score": round(avg_dissimilar, 4),
                    "score_separation": round(avg_similar - avg_dissimilar, 4),
                    "expected_behavior": avg_similar > avg_dissimilar
                }
                
                logger.info(f"✅ 相似度准确性测试完成:")
                logger.info(f"  平均相似查询分数: {avg_similar:.4f}")
                logger.info(f"  平均不相似查询分数: {avg_dissimilar:.4f}")
                logger.info(f"  分数分离度: {avg_similar - avg_dissimilar:.4f}")
                
            return results
            
        except Exception as e:
            logger.error(f"❌ 相似度准确性测试失败: {str(e)}")
            results["error"] = str(e)
            return results
    
    def run_all_tests(self) -> Dict[str, Any]:
        """运行所有数据库测试"""
        logger.info("=" * 60)
        logger.info("开始数据库向量搜索功能测试")
        logger.info("=" * 60)
        
        all_results = {
            "test_timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "database_connection": None,
            "pgvector_extension": None,
            "data_integrity": None,
            "embedding_generation": None,
            "vector_search": None,
            "similarity_accuracy": None,
            "overall_success": False
        }
        
        # 1. 数据库连接测试
        logger.info("\n1. 数据库连接测试")
        connection_success = self.connect_database()
        all_results["database_connection"] = {"success": connection_success}
        
        if not connection_success:
            logger.error("数据库连接失败，跳过后续测试")
            return all_results
        
        # 2. pgvector扩展测试
        logger.info("\n2. pgvector扩展测试")
        all_results["pgvector_extension"] = self.test_pgvector_extension()
        
        # 3. 数据完整性测试
        logger.info("\n3. 数据完整性测试")
        all_results["data_integrity"] = self.test_data_integrity()
        
        # 4. 向量嵌入生成测试
        logger.info("\n4. 向量嵌入生成测试")
        all_results["embedding_generation"] = self.test_embedding_generation()
        
        # 5. 向量搜索功能测试
        logger.info("\n5. 向量搜索功能测试")
        all_results["vector_search"] = self.test_vector_search_direct()
        
        # 6. 相似度准确性测试
        logger.info("\n6. 相似度准确性测试")
        all_results["similarity_accuracy"] = self.test_vector_similarity_accuracy()
        
        # 判断整体成功状态
        critical_tests = [
            all_results["database_connection"]["success"],
            all_results["pgvector_extension"]["pgvector_installed"],
            all_results["data_integrity"]["data_integrity"],
            all_results["embedding_generation"]["success"],
            all_results["vector_search"]["overall_success"]
        ]
        
        all_results["overall_success"] = all(critical_tests)
        
        # 输出测试摘要
        logger.info("\n" + "=" * 60)
        logger.info("数据库测试完成摘要")
        logger.info("=" * 60)
        logger.info(f"数据库连接: {'✅' if all_results['database_connection']['success'] else '❌'}")
        logger.info(f"pgvector扩展: {'✅' if all_results['pgvector_extension']['pgvector_installed'] else '❌'}")
        logger.info(f"数据完整性: {'✅' if all_results['data_integrity']['data_integrity'] else '❌'}")
        logger.info(f"向量生成: {'✅' if all_results['embedding_generation']['success'] else '❌'}")
        logger.info(f"向量搜索: {'✅' if all_results['vector_search']['overall_success'] else '❌'}")
        logger.info(f"整体状态: {'✅ 所有测试通过' if all_results['overall_success'] else '❌ 存在测试失败'}")
        
        return all_results

def main():
    """主函数"""
    tester = DatabaseVectorTester()
    results = tester.run_all_tests()
    
    # 保存测试结果
    import json
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    output_file = f"database_test_results_{timestamp}.json"
    
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    
    logger.info(f"\n测试结果已保存到: {output_file}")
    
    return results

if __name__ == "__main__":
    main()