#!/usr/bin/env python3
"""
修复版向量搜索评估脚本

主要修复:
1. 处理期望结果中的 * 前缀
2. 改进字符串匹配逻辑，支持模糊匹配
3. 添加详细的分析输出
"""

import os
import sys
import time
import json
import argparse
from typing import Optional, List, Dict
import re

import numpy as np
import pandas as pd
import psycopg2
import requests

try:
    from pgvector.psycopg2 import register_vector
    PGVECTOR_AVAILABLE = True
except Exception:
    PGVECTOR_AVAILABLE = False


def normalize_procedure_name(name: str) -> str:
    """标准化检查项目名称，去除前缀符号和多余空格"""
    if not name:
        return ""
    # 去除 * 前缀和多余空格
    normalized = name.strip()
    if normalized.startswith('*'):
        normalized = normalized[1:].strip()
    return normalized


def fuzzy_match_procedure(expected: str, actual: str, threshold: float = 0.8) -> float:
    """模糊匹配两个检查项目名称，返回匹配度"""
    expected_norm = normalize_procedure_name(expected).lower()
    actual_norm = normalize_procedure_name(actual).lower()
    
    # 精确匹配
    if expected_norm == actual_norm:
        return 1.0
    
    # 包含匹配
    if expected_norm in actual_norm or actual_norm in expected_norm:
        return 0.9
    
    # 计算字符相似度
    if len(expected_norm) == 0 or len(actual_norm) == 0:
        return 0.0
    
    # 简单的字符匹配率
    common_chars = sum(1 for c in expected_norm if c in actual_norm)
    max_len = max(len(expected_norm), len(actual_norm))
    char_similarity = common_chars / max_len
    
    return char_similarity


def embed_with_siliconflow(text: str, api_key: Optional[str] = None, model: str = "BAAI/bge-m3", timeout: int = 60) -> List[float]:
    api_key = api_key or os.getenv("SILICONFLOW_API_KEY")
    if not api_key:
        print("[warn] SILICONFLOW_API_KEY not set; using random vector")
        return np.random.rand(1024).tolist()
    try:
        headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
        payload = {"model": model, "input": text}
        resp = requests.post("https://api.siliconflow.cn/v1/embeddings", json=payload, headers=headers, timeout=timeout)
        resp.raise_for_status()
        data = resp.json()
        return data["data"][0]["embedding"]
    except Exception as e:
        print(f"[warn] SiliconFlow embedding failed: {e}; using random vector")
        return np.random.rand(1024).tolist()


def connect_db() -> psycopg2.extensions.connection:
    cfg = dict(
        host=os.getenv("PGHOST", "localhost"),
        port=os.getenv("PGPORT", "5432"),
        database=os.getenv("PGDATABASE", "acrac_db"),
        user=os.getenv("PGUSER", "postgres"),
        password=os.getenv("PGPASSWORD", "password"),
    )
    conn = psycopg2.connect(**cfg)
    if PGVECTOR_AVAILABLE:
        register_vector(conn)
    return conn


def search_recommendations(conn, query_vector: List[float], top_k: int = 5) -> List[Dict]:
    """Top-K recommendations via pgvector cosine distance."""
    with conn.cursor() as cur:
        if PGVECTOR_AVAILABLE:
            sql = (
                """
                SELECT
                    cr.semantic_id,
                    pd.name_zh AS procedure_name_zh,
                    pd.name_en AS procedure_name_en,
                    pd.modality,
                    pd.body_part,
                    cr.appropriateness_rating,
                    cr.appropriateness_category_zh,
                    cr.reasoning_zh,
                    cr.evidence_level,
                    (1 - (cr.embedding <=> %s::vector)) AS similarity,
                    cs.description_zh AS scenario_desc
                FROM clinical_recommendations cr
                JOIN procedure_dictionary pd ON cr.procedure_id = pd.semantic_id
                JOIN clinical_scenarios cs ON cr.scenario_id = cs.semantic_id
                WHERE cr.embedding IS NOT NULL
                ORDER BY cr.embedding <=> %s::vector
                LIMIT %s
                """
            )
            cur.execute(sql, (query_vector, query_vector, top_k))
        else:
            vec_str = "[" + ",".join(map(str, query_vector)) + "]"
            sql = (
                f"""
                SELECT
                    cr.semantic_id,
                    pd.name_zh AS procedure_name_zh,
                    pd.name_en AS procedure_name_en,
                    pd.modality,
                    pd.body_part,
                    cr.appropriateness_rating,
                    cr.appropriateness_category_zh,
                    cr.reasoning_zh,
                    cr.evidence_level,
                    (1 - (cr.embedding <=> '{vec_str}'::vector)) AS similarity,
                    cs.description_zh AS scenario_desc
                FROM clinical_recommendations cr
                JOIN procedure_dictionary pd ON cr.procedure_id = pd.semantic_id
                JOIN clinical_scenarios cs ON cr.scenario_id = cs.semantic_id
                WHERE cr.embedding IS NOT NULL
                ORDER BY cr.embedding <=> '{vec_str}'::vector
                LIMIT {top_k}
                """
            )
            cur.execute(sql)
        rows = cur.fetchall()
    
    results = []
    for r in rows:
        results.append(
            dict(
                rec_id=r[0],
                procedure_name_zh=r[1] or "",
                procedure_name_en=r[2] or "",
                modality=r[3],
                body_part=r[4],
                rating=r[5],
                category_zh=r[6],
                reasoning_zh=r[7],
                evidence=r[8],
                similarity=float(r[9]),
                scenario_desc=r[10] or "",
            )
        )
    return results


def main():
    ap = argparse.ArgumentParser(description="Fixed vector search evaluation from Excel")
    ap.add_argument("--excel-path", required=True, help="Path to Excel file with test cases")
    ap.add_argument("--query-col", default="临床场景", help="Column containing query text")
    ap.add_argument("--expected-procedure-col", default="首选检查项目（标准化）", help="Column with expected procedure")
    ap.add_argument("--top-k", type=int, default=10, help="Top-K for retrieval")
    ap.add_argument("--limit", type=int, default=50, help="Max rows to evaluate (0=all)")
    ap.add_argument("--fuzzy-threshold", type=float, default=0.8, help="Fuzzy matching threshold")
    args = ap.parse_args()

    # 加载Excel数据
    df = pd.read_excel(args.excel_path)
    if args.query_col not in df.columns:
        raise ValueError(f"Column '{args.query_col}' not found in Excel. Available: {list(df.columns)}")

    has_expected = bool(args.expected_procedure_col and args.expected_procedure_col in df.columns)
    if not has_expected:
        print("Warning: No expected procedure column specified or found")

    conn = connect_db()

    # 统计变量
    total = 0
    exact_top1_hits = 0
    exact_topk_hits = 0
    fuzzy_top1_hits = 0
    fuzzy_topk_hits = 0
    
    detailed_results = []

    print("🔍 开始向量搜索评估测试")
    print("=" * 60)

    t0 = time.time()
    for idx, row in df.iterrows():
        if args.limit and total >= args.limit:
            break
        
        query = str(row[args.query_col]).strip()
        if not query:
            continue
        
        total += 1
        expected = str(row[args.expected_procedure_col]).strip() if has_expected else ""
        expected_norm = normalize_procedure_name(expected)

        # 生成向量并搜索
        qvec = embed_with_siliconflow(query)
        results = search_recommendations(conn, qvec, top_k=args.top_k)

        print(f"\n=== 查询 #{total} ===")
        print(f"临床场景: {query}")
        if has_expected:
            print(f"期望检查: {expected}")
            print(f"标准化后: {expected_norm}")

        # 显示搜索结果
        names = [r["procedure_name_zh"] for r in results]
        print("搜索结果:")
        for i, r in enumerate(results, 1):
            marker = ""
            if has_expected:
                # 精确匹配检查
                if r["procedure_name_zh"] == expected_norm:
                    marker = " ✅ 精确匹配"
                else:
                    # 模糊匹配检查
                    match_score = fuzzy_match_procedure(expected, r["procedure_name_zh"])
                    if match_score >= args.fuzzy_threshold:
                        marker = f" 🟡 模糊匹配({match_score:.2f})"
            
            print(f"  {i:2d}. {r['procedure_name_zh']} ({r['modality']}) sim={r['similarity']:.4f}{marker}")

        # 统计命中情况
        if has_expected and expected_norm:
            # 精确匹配统计
            if len(names) > 0 and names[0] == expected_norm:
                exact_top1_hits += 1
            if expected_norm in names:
                exact_topk_hits += 1
            
            # 模糊匹配统计
            fuzzy_matches = [fuzzy_match_procedure(expected, name) >= args.fuzzy_threshold for name in names]
            if len(fuzzy_matches) > 0 and fuzzy_matches[0]:
                fuzzy_top1_hits += 1
            if any(fuzzy_matches):
                fuzzy_topk_hits += 1
            
            # 记录详细结果
            result_detail = {
                "query_id": total,
                "query": query,
                "expected": expected,
                "expected_norm": expected_norm,
                "top1_result": names[0] if names else "",
                "exact_top1_hit": len(names) > 0 and names[0] == expected_norm,
                "exact_topk_hit": expected_norm in names,
                "fuzzy_top1_hit": len(fuzzy_matches) > 0 and fuzzy_matches[0],
                "fuzzy_topk_hit": any(fuzzy_matches),
                "similarity_scores": [r["similarity"] for r in results[:5]]
            }
            detailed_results.append(result_detail)

    conn.close()

    # 输出最终统计结果
    t1 = time.time()
    print("\n" + "=" * 60)
    print("📊 测试结果汇总")
    print("=" * 60)
    print(f"总查询数: {total}")
    print(f"总耗时: {(t1 - t0):.2f}秒")
    print(f"平均耗时: {(t1 - t0)/total:.2f}秒/查询")
    
    if has_expected and total:
        print(f"\n精确匹配结果:")
        print(f"  Top-1 准确率: {exact_top1_hits}/{total} = {exact_top1_hits/total:.3f} ({exact_top1_hits/total*100:.1f}%)")
        print(f"  Top-{args.top_k} 命中率: {exact_topk_hits}/{total} = {exact_topk_hits/total:.3f} ({exact_topk_hits/total*100:.1f}%)")
        
        print(f"\n模糊匹配结果 (阈值≥{args.fuzzy_threshold}):")
        print(f"  Top-1 准确率: {fuzzy_top1_hits}/{total} = {fuzzy_top1_hits/total:.3f} ({fuzzy_top1_hits/total*100:.1f}%)")
        print(f"  Top-{args.top_k} 命中率: {fuzzy_topk_hits}/{total} = {fuzzy_topk_hits/total:.3f} ({fuzzy_topk_hits/total*100:.1f}%)")

        # 分析失败案例
        failed_cases = [r for r in detailed_results if not r["fuzzy_topk_hit"]]
        if failed_cases:
            print(f"\n❌ 完全失败案例 ({len(failed_cases)}个):")
            for case in failed_cases[:5]:  # 只显示前5个
                print(f"  - 查询{case['query_id']}: {case['query'][:30]}...")
                print(f"    期望: {case['expected_norm']}")
                print(f"    得到: {case['top1_result']}")

        # 保存详细结果
        output_file = f"evaluation_results_{int(time.time())}.json"
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump({
                "summary": {
                    "total_queries": total,
                    "exact_top1_accuracy": exact_top1_hits/total if total > 0 else 0,
                    "exact_topk_hit_rate": exact_topk_hits/total if total > 0 else 0,
                    "fuzzy_top1_accuracy": fuzzy_top1_hits/total if total > 0 else 0,
                    "fuzzy_topk_hit_rate": fuzzy_topk_hits/total if total > 0 else 0,
                    "elapsed_time": t1 - t0
                },
                "detailed_results": detailed_results
            }, f, ensure_ascii=False, indent=2)
        
        print(f"\n💾 详细结果已保存到: {output_file}")


if __name__ == "__main__":
    main()