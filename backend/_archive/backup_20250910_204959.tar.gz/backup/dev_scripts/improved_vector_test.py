#!/usr/bin/env python3
"""
改进的向量搜索测试，使用更灵活的匹配逻辑
"""

import os
import sys
import time
import pandas as pd
import psycopg2
from pgvector.psycopg2 import register_vector
from evaluate_vector_search_from_excel import embed_with_siliconflow, search_recommendations

def normalize_procedure_name(name):
    """标准化检查项目名称，去除特殊字符和空格"""
    if not name:
        return ""
    # 去除开头的*号和空格
    name = name.strip().lstrip('*').strip()
    # 去除多余空格
    name = ' '.join(name.split())
    return name

def is_match(expected, actual):
    """检查期望结果是否与实际结果匹配"""
    if not expected or not actual:
        return False
    
    expected_norm = normalize_procedure_name(expected)
    actual_norm = normalize_procedure_name(actual)
    
    # 精确匹配
    if expected_norm == actual_norm:
        return True
    
    # 包含匹配
    if expected_norm in actual_norm or actual_norm in expected_norm:
        return True
    
    # 关键词匹配（提取主要关键词）
    expected_keywords = set(expected_norm.replace('(', ' ').replace(')', ' ').split())
    actual_keywords = set(actual_norm.replace('(', ' ').replace(')', ' ').split())
    
    # 如果期望的关键词大部分都在实际结果中
    if expected_keywords and actual_keywords:
        overlap = len(expected_keywords & actual_keywords)
        if overlap >= len(expected_keywords) * 0.7:  # 70%的关键词匹配
            return True
    
    return False

def improved_test():
    # 连接数据库
    conn = psycopg2.connect(
        host='localhost',
        port='5432', 
        database='acrac_db',
        user='postgres',
        password='password'
    )
    register_vector(conn)

    # 读取测试数据
    df = pd.read_excel('../影像测试样例-0318-1.xlsx')
    print(f"测试数据行数: {len(df)}")
    
    total = 0
    top1_hits = 0
    top5_hits = 0
    
    t0 = time.time()
    
    for idx, row in df.iterrows():
        scenario = str(row['临床场景']).strip()
        expected = str(row['首选检查项目（标准化）']).strip()
        
        if not scenario:
            continue
            
        total += 1
        
        # 生成查询向量
        query_vector = embed_with_siliconflow(scenario)
        
        # 搜索推荐
        results = search_recommendations(conn, query_vector, top_k=5)
        
        print(f"\n=== Query #{total} ===")
        print(f"场景: {scenario}")
        print(f"期望: {expected}")
        
        # 检查匹配
        top1_match = False
        top5_match = False
        
        for i, r in enumerate(results, 1):
            procedure_name = r['procedure_name_zh']
            similarity = r['similarity']
            modality = r['modality']
            
            print(f"  {i}. {procedure_name} ({modality}) sim={similarity:.4f}")
            
            # 检查是否匹配
            if is_match(expected, procedure_name):
                if i == 1:
                    top1_match = True
                top5_match = True
                print(f"    *** 匹配! ***")
        
        if top1_match:
            top1_hits += 1
        if top5_match:
            top5_hits += 1
    
    conn.close()
    
    t1 = time.time()
    print(f"\n==== 改进的测试结果 ====")
    print(f"评估查询数: {total}; 耗时: {(t1 - t0):.2f}s")
    print(f"Top-1 准确率: {top1_hits / total:.3f}")
    print(f"Top-5 命中率: {top5_hits / total:.3f}")

if __name__ == "__main__":
    improved_test()
