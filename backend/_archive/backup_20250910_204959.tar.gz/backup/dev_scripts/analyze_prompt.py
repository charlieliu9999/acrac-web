#!/usr/bin/env python3
"""
提示词内容分析脚本
显示完整的提示词内容并分析优化问题
"""

import requests
import json
import sys

def analyze_prompt():
    """分析提示词内容"""
    
    # 发送请求获取调试信息
    url = "http://localhost:8001/api/v1/acrac/rag-llm/intelligent-recommendation"
    payload = {
        "clinical_query": "45岁女性，慢性反复头痛3年，无神经系统异常体征",
        "debug_mode": True,
        "include_raw_data": True
    }
    
    try:
        response = requests.post(url, json=payload, timeout=60)
        if response.status_code != 200:
            print(f"❌ API请求失败: {response.status_code}")
            return
        
        result = response.json()
        debug_info = result.get("debug_info", {})
        
        print("🔍 提示词内容完整分析")
        print("=" * 80)
        
        # 1. 基本统计
        prompt_length = debug_info.get("step_6_prompt_length", 0)
        scenarios_count = len(result.get("scenarios_with_recommendations", []))
        
        print(f"📊 基本统计:")
        print(f"   提示词长度: {prompt_length} 字符")
        print(f"   场景数量: {scenarios_count} 个")
        print(f"   模型: {result.get('model_used', 'N/A')}")
        print(f"   处理时间: {result.get('processing_time_ms', 0)}ms")
        print()
        
        # 2. 显示完整提示词（如果可用）
        if "step_6_prompt_preview" in debug_info:
            print("📝 完整提示词内容:")
            print("-" * 80)
            print(debug_info["step_6_prompt_preview"])
            print("-" * 80)
            print()
        
        # 3. 分析场景数据质量
        scenarios_with_recs = result.get("scenarios_with_recommendations", [])
        if scenarios_with_recs:
            print(f"🔬 场景数据质量分析:")
            for i, scenario in enumerate(scenarios_with_recs, 1):
                print(f"   场景 {i}: [{scenario['scenario_id']}]")
                
                # 检查空字段
                empty_fields = []
                field_names = ['patient_population', 'risk_level', 'age_group', 'gender', 'urgency_level']
                for field in field_names:
                    if not scenario.get(field) or scenario.get(field) == 'None':
                        empty_fields.append(field)
                
                if empty_fields:
                    print(f"      ❌ 空字段: {', '.join(empty_fields)}")
                else:
                    print(f"      ✅ 数据完整")
                
                rec_count = len(scenario.get('recommendations', []))
                print(f"      📋 推荐数: {rec_count} 个")
        
        print()
        
        # 4. 优化建议
        print("💡 优化建议:")
        
        # 长度问题
        if prompt_length > 4000:
            print("   🚨 提示词过长 (>4000字符)，可能影响模型性能")
        elif prompt_length > 3000:
            print("   ⚠️  提示词较长 (>3000字符)，建议优化")
        else:
            print("   ✅ 提示词长度合理")
        
        # 场景数量
        if scenarios_count > 2:
            print(f"   ⚠️  场景数量较多 ({scenarios_count}个)，考虑限制为Top 2")
        else:
            print(f"   ✅ 场景数量合理 ({scenarios_count}个)")
        
        # 空字段问题  
        total_empty_fields = 0
        for scenario in scenarios_with_recs:
            field_names = ['patient_population', 'risk_level', 'age_group', 'gender', 'urgency_level']
            for field in field_names:
                if not scenario.get(field) or scenario.get(field) == 'None':
                    total_empty_fields += 1
        
        if total_empty_fields > 0:
            print(f"   🚨 发现 {total_empty_fields} 个空字段，建议移除")
        else:
            print("   ✅ 无空字段问题")
            
        print()
        
        # 5. 优化方案预览
        print("🛠️ 具体优化方案:")
        print("   1. 移除空字段 (patient_population, risk_level, age_group, gender, urgency_level)")
        print("   2. 简化推荐详情 (减少不必要的字段)")
        print("   3. 限制场景数量为Top 2")
        print("   4. 压缩提示词模板")
        
    except Exception as e:
        print(f"❌ 分析失败: {e}")

if __name__ == "__main__":
    analyze_prompt()