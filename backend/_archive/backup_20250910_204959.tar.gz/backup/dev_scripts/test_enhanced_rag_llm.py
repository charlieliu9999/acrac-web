#!/usr/bin/env python3
"""
增强版RAG+LLM智能推荐系统测试脚本
测试新功能：Qwen2.5-32B、阈值判断、调试模式、场景组织推荐
"""

import requests
import json
import time
from typing import Dict, Any

class EnhancedRAGLLMTester:
    """增强版RAG+LLM系统测试器"""
    
    def __init__(self, base_url: str = "http://localhost:8001"):
        self.base_url = base_url
        self.api_endpoint = f"{base_url}/api/v1/acrac/rag-llm/intelligent-recommendation"
        
    def test_with_debug(self, query: str, include_raw_data: bool = True, debug_mode: bool = True) -> Dict[str, Any]:
        """测试带调试信息的查询"""
        payload = {
            "clinical_query": query,
            "include_raw_data": include_raw_data,
            "debug_mode": debug_mode
        }
        
        try:
            start_time = time.time()
            response = requests.post(
                self.api_endpoint,
                json=payload,
                headers={"Content-Type": "application/json"},
                timeout=120  # 增加超时时间，因为使用32B模型
            )
            end_time = time.time()
            
            if response.status_code == 200:
                result = response.json()
                result["api_response_time_ms"] = int((end_time - start_time) * 1000)
                return result
            else:
                return {
                    "success": False,
                    "error": f"HTTP {response.status_code}: {response.text}",
                    "api_response_time_ms": int((end_time - start_time) * 1000)
                }
                
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "api_response_time_ms": -1
            }
    
    def print_debug_info(self, result: Dict[str, Any]):
        """打印详细的调试信息"""
        if not result.get("success"):
            print(f"❌ 测试失败: {result.get('error', 'Unknown error')}")
            return
        
        print("🔍 详细调试信息:")
        print("=" * 80)
        
        # 基本信息
        print(f"📋 基本信息:")
        print(f"   查询: {result.get('query', 'N/A')}")
        print(f"   模型: {result.get('model_used', 'N/A')}")
        print(f"   总耗时: {result.get('api_response_time_ms', 'N/A')}ms")
        print(f"   LLM耗时: {result.get('processing_time_ms', 'N/A')}ms")
        print(f"   相似度阈值: {result.get('similarity_threshold', 'N/A')}")
        print(f"   最高相似度: {result.get('max_similarity', 'N/A'):.3f}")
        print(f"   低相似度模式: {result.get('is_low_similarity_mode', 'N/A')}")
        print()
        
        # 调试详情
        debug_info = result.get("debug_info", {})
        if debug_info:
            print(f"🛠️ 处理流程:")
            
            # 步骤1: 查询处理
            if "step_1_query" in debug_info:
                print(f"   Step 1 - 查询: {debug_info['step_1_query']}")
            
            # 步骤2: 向量生成
            if "step_2_vector_generation" in debug_info:
                vector_info = debug_info["step_2_vector_generation"]
                print(f"   Step 2 - 向量生成: 维度={vector_info['vector_dimension']}, 样本={vector_info['vector_sample']}")
            
            # 步骤3: 场景搜索
            if "step_3_scenarios_search" in debug_info:
                scenarios_info = debug_info["step_3_scenarios_search"]
                print(f"   Step 3 - 场景搜索: 找到{scenarios_info['found_scenarios']}个场景")
                for i, scenario in enumerate(scenarios_info['scenarios'], 1):
                    print(f"     {i}. [{scenario['id']}] 相似度={scenario['similarity']:.3f} | {scenario['description']}")
            
            # 步骤4: 相似度检查
            if "step_4_similarity_check" in debug_info:
                sim_info = debug_info["step_4_similarity_check"]
                print(f"   Step 4 - 相似度检查: 最高={sim_info['max_similarity']:.3f}, 阈值={sim_info['threshold']}, 状态={sim_info['similarity_status']}")
            
            # 步骤5: 模式选择
            if "step_5_mode" in debug_info:
                mode = debug_info["step_5_mode"]
                print(f"   Step 5 - 推理模式: {mode}")
                
                if mode == "rag" and "step_5_scenarios_with_recs" in debug_info:
                    rag_info = debug_info["step_5_scenarios_with_recs"]
                    print(f"     RAG数据: {rag_info['scenarios_count']}个场景, {rag_info['total_recommendations']}个推荐")
                    for scenario in rag_info['scenarios_summary']:
                        print(f"       - [{scenario['id']}] {scenario['description']} | 推荐数: {scenario['recommendations_count']}")
            
            # 步骤6: 提示词准备
            if "step_6_prompt_length" in debug_info:
                print(f"   Step 6 - 提示词: 长度={debug_info['step_6_prompt_length']}字符")
                if "step_6_prompt_preview" in debug_info:
                    print(f"     预览: {debug_info['step_6_prompt_preview']}")
            
            # 步骤7-9: LLM处理
            if "step_7_llm_response_length" in debug_info:
                print(f"   Step 7 - LLM响应: 长度={debug_info['step_7_llm_response_length']}字符")
            if "step_8_parsing_success" in debug_info:
                print(f"   Step 8 - 解析结果: {'成功' if debug_info['step_8_parsing_success'] else '失败'}")
            if "step_9_total_time_ms" in debug_info:
                print(f"   Step 9 - 总处理时间: {debug_info['step_9_total_time_ms']}ms")
        
        print()
        
        # 场景详情（如果有原始数据）
        scenarios = result.get("scenarios", [])
        if scenarios:
            print(f"📋 匹配的临床场景 (Top {len(scenarios)}):")
            for i, scenario in enumerate(scenarios, 1):
                print(f"   {i}. [{scenario['semantic_id']}] 相似度: {scenario['similarity']:.3f}")
                print(f"      描述: {scenario['description_zh']}")
                print(f"      科室: {scenario.get('panel_name', 'N/A')} | 主题: {scenario.get('topic_name', 'N/A')}")
                print()
        
        # 场景及推荐详情
        scenarios_with_recs = result.get("scenarios_with_recommendations", [])
        if scenarios_with_recs:
            print(f"🔬 场景及其推荐详情:")
            for i, scenario_data in enumerate(scenarios_with_recs, 1):
                print(f"   场景 {i}: [{scenario_data['scenario_id']}]")
                print(f"   描述: {scenario_data['scenario_description']}")
                print(f"   科室: {scenario_data.get('panel_name', 'N/A')} | 主题: {scenario_data.get('topic_name', 'N/A')}")
                
                recs = scenario_data.get("recommendations", [])
                if recs:
                    print(f"   该场景下的推荐检查 ({len(recs)}个):")
                    for j, rec in enumerate(recs[:3], 1):  # 只显示前3个
                        print(f"     {j}. {rec['procedure_name_zh']} ({rec['modality']}) - 评分: {rec['appropriateness_rating']}/9")
                        print(f"        理由: {rec.get('reasoning_zh', 'N/A')[:100]}...")
                else:
                    print(f"   该场景暂无高评分推荐")
                print()
        
        # LLM推荐结果
        llm_recs = result.get("llm_recommendations", {})
        if llm_recs:
            print(f"🤖 LLM最终推荐:")
            
            # 显示是否为无RAG模式
            if llm_recs.get("no_rag"):
                print(f"   ⚠️  {llm_recs.get('rag_note', '无RAG模式推荐')}")
            
            recommendations = llm_recs.get("recommendations", [])
            for i, rec in enumerate(recommendations, 1):
                print(f"   {i}. {rec.get('procedure_name', 'N/A')} ({rec.get('modality', 'N/A')})")
                print(f"      评分: {rec.get('appropriateness_rating', 'N/A')}")
                print(f"      理由: {rec.get('recommendation_reason', 'N/A')[:150]}...")
                print(f"      考虑: {rec.get('clinical_considerations', 'N/A')}")
                print()
            
            print(f"   💡 推荐总结: {llm_recs.get('summary', 'N/A')}")
        
        # 原始LLM响应（调试模式）
        if result.get("llm_raw_response") and len(result["llm_raw_response"]) > 0:
            print(f"\n🔍 LLM原始响应预览:")
            print(f"   {result['llm_raw_response'][:300]}...")
        
        print("\n" + "=" * 80)

def main():
    """主测试函数"""
    tester = EnhancedRAGLLMTester()
    
    # 测试案例
    test_cases = [
        {
            "name": "高相似度案例（RAG模式）",
            "query": "45岁女性，慢性反复头痛3年，无神经系统异常体征",
            "expected_mode": "rag"
        },
        {
            "name": "中等相似度案例",
            "query": "55岁男性，新发头痛，伴发热和颈部僵硬", 
            "expected_mode": "rag"
        },
        {
            "name": "低相似度案例（可能触发无RAG模式）",
            "query": "30岁程序员，长期电脑工作后出现手腕疼痛和麻木",
            "expected_mode": "可能no_rag"
        },
        {
            "name": "复杂症状案例",
            "query": "50岁女性，3天前开始出现左侧肢体无力，伴新发头痛",
            "expected_mode": "rag"
        }
    ]
    
    print("🚀 增强版RAG+LLM智能推荐系统测试")
    print("=" * 80)
    print(f"模型: Qwen2.5-32B-Instruct")
    print(f"功能: 阈值判断、调试模式、场景组织推荐")
    print("=" * 80)
    
    for i, test_case in enumerate(test_cases, 1):
        print(f"\n🔍 测试案例 #{i}: {test_case['name']}")
        print(f"查询: {test_case['query']}")
        print(f"预期模式: {test_case['expected_mode']}")
        print("-" * 60)
        
        # 执行测试
        result = tester.test_with_debug(test_case['query'])
        
        # 打印详细信息
        tester.print_debug_info(result)
        
        # 等待一段时间避免API限制
        time.sleep(2)
    
    print("\n✅ 所有测试完成！")

if __name__ == "__main__":
    main()