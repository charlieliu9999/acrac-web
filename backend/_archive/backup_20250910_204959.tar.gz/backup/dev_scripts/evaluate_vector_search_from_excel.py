#!/usr/bin/env python3
"""
Evaluate vector retrieval against an Excel dataset.

- Generates query embeddings via local Ollama (bge-m3:latest)
- Queries PostgreSQL (pgvector) for top-K clinical recommendations
- Optionally measures hit rate if expected columns are provided

Usage:
  python backend/scripts/evaluate_vector_search_from_excel.py \
    --excel-path ./影像测试样例-0318-1.xlsx \
    --query-col 患者主诉 \
    --expected-procedure-col 期望检查 \
    --top-k 5

Environment:
  PGHOST, PGPORT, PGDATABASE, PGUSER, PGPASSWORD
  OLLAMA_BASE_URL (default: http://localhost:11434)
"""

import os
import sys
import time
import json
import argparse
from typing import Optional, List, Dict

import numpy as np
import pandas as pd
import psycopg2
import requests

try:
    from pgvector.psycopg2 import register_vector  # type: ignore
    PGVECTOR_AVAILABLE = True
except Exception:
    PGVECTOR_AVAILABLE = False


def load_excel(path: str) -> pd.DataFrame:
    if not os.path.exists(path):
        raise FileNotFoundError(f"Excel not found: {path}")
    df = pd.read_excel(path)
    return df.fillna("")


def embed_with_ollama(text: str, base_url: str = "http://localhost:11434", model: str = "bge-m3:latest", timeout: int = 60) -> List[float]:
    try:
        resp = requests.post(
            f"{base_url.rstrip('/')}/api/embeddings",
            json={"model": model, "prompt": text},
            timeout=timeout,
        )
        resp.raise_for_status()
        vec = resp.json().get("embedding", [])
        if not isinstance(vec, list) or not vec:
            raise RuntimeError("Invalid embedding response")
        return vec
    except Exception as e:
        print(f"[warn] Ollama embedding failed: {e}; using random vector")
        return np.random.rand(1024).tolist()


def embed_with_siliconflow(text: str, api_key: Optional[str] = None, model: str = "BAAI/bge-m3", timeout: int = 60) -> List[float]:
    api_key = api_key or os.getenv("SILICONFLOW_API_KEY")
    if not api_key:
        print("[warn] SILICONFLOW_API_KEY not set; using random vector")
        return np.random.rand(1024).tolist()
    try:
        headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
        payload = {"model": model, "input": text}
        resp = requests.post("https://api.siliconflow.cn/v1/embeddings", json=payload, headers=headers, timeout=timeout)
        resp.raise_for_status()
        data = resp.json()
        return data["data"][0]["embedding"]
    except Exception as e:
        print(f"[warn] SiliconFlow embedding failed: {e}; using random vector")
        return np.random.rand(1024).tolist()


def connect_db() -> psycopg2.extensions.connection:
    cfg = dict(
        host=os.getenv("PGHOST", "localhost"),
        port=os.getenv("PGPORT", "5432"),
        database=os.getenv("PGDATABASE", "acrac_db"),
        user=os.getenv("PGUSER", "postgres"),
        password=os.getenv("PGPASSWORD", "password"),
    )
    conn = psycopg2.connect(**cfg)
    if PGVECTOR_AVAILABLE:
        register_vector(conn)
    return conn


def search_recommendations(conn, query_vector: List[float], top_k: int = 5) -> List[Dict]:
    """Top-K recommendations via pgvector cosine distance."""
    with conn.cursor() as cur:
        # Use parameterized vector when pgvector adapter available, else cast string
        if PGVECTOR_AVAILABLE:
            sql = (
                """
                SELECT
                    cr.semantic_id,
                    pd.name_zh AS procedure_name_zh,
                    pd.name_en AS procedure_name_en,
                    pd.modality,
                    pd.body_part,
                    cr.appropriateness_rating,
                    cr.appropriateness_category_zh,
                    cr.reasoning_zh,
                    cr.evidence_level,
                    (1 - (cr.embedding <=> %s::vector)) AS similarity,
                    cs.description_zh AS scenario_desc
                FROM clinical_recommendations cr
                JOIN procedure_dictionary pd ON cr.procedure_id = pd.semantic_id
                JOIN clinical_scenarios cs ON cr.scenario_id = cs.semantic_id
                WHERE cr.embedding IS NOT NULL
                ORDER BY cr.embedding <=> %s::vector
                LIMIT %s
                """
            )
            cur.execute(sql, (query_vector, query_vector, top_k))
        else:
            vec_str = "[" + ",".join(map(str, query_vector)) + "]"
            sql = (
                f"""
                SELECT
                    cr.semantic_id,
                    pd.name_zh AS procedure_name_zh,
                    pd.name_en AS procedure_name_en,
                    pd.modality,
                    pd.body_part,
                    cr.appropriateness_rating,
                    cr.appropriateness_category_zh,
                    cr.reasoning_zh,
                    cr.evidence_level,
                    (1 - (cr.embedding <=> '{vec_str}'::vector)) AS similarity,
                    cs.description_zh AS scenario_desc
                FROM clinical_recommendations cr
                JOIN procedure_dictionary pd ON cr.procedure_id = pd.semantic_id
                JOIN clinical_scenarios cs ON cr.scenario_id = cs.semantic_id
                WHERE cr.embedding IS NOT NULL
                ORDER BY cr.embedding <=> '{vec_str}'::vector
                LIMIT {top_k}
                """
            )
            cur.execute(sql)
        rows = cur.fetchall()
    results = []
    for r in rows:
        results.append(
            dict(
                rec_id=r[0],
                procedure_name_zh=r[1] or "",
                procedure_name_en=r[2] or "",
                modality=r[3],
                body_part=r[4],
                rating=r[5],
                category_zh=r[6],
                reasoning_zh=r[7],
                evidence=r[8],
                similarity=float(r[9]),
                scenario_desc=r[10] or "",
            )
        )
    return results


def main():
    ap = argparse.ArgumentParser(description="Evaluate vector search from Excel")
    ap.add_argument("--excel-path", required=True, help="Path to Excel file with test cases")
    ap.add_argument("--query-col", default="query_text", help="Column containing query text")
    ap.add_argument("--expected-procedure-col", default="", help="Optional column with expected procedure (中文名)")
    ap.add_argument("--top-k", type=int, default=5, help="Top-K for retrieval")
    ap.add_argument("--limit", type=int, default=50, help="Max rows to evaluate (0=all)")
    ap.add_argument("--ollama-url", default=os.getenv("OLLAMA_BASE_URL", "http://localhost:11434"))
    ap.add_argument("--embedder", choices=["ollama", "siliconflow"], default="ollama", help="Embedding provider for queries")
    ap.add_argument("--sf-model", default=os.getenv("SILICONFLOW_EMBEDDING_MODEL", "BAAI/bge-m3"), help="SiliconFlow embedding model")
    args = ap.parse_args()

    df = load_excel(args.excel_path)
    if args.query_col not in df.columns:
        raise ValueError(f"Column '{args.query_col}' not found in Excel. Available: {list(df.columns)}")

    has_expected = bool(args.expected_procedure_col and args.expected_procedure_col in df.columns)

    conn = connect_db()

    total = 0
    top1_hits = 0
    topk_hits = 0

    t0 = time.time()
    for idx, row in df.iterrows():
        if args.limit and total >= args.limit:
            break
        q = str(row[args.query_col]).strip()
        if not q:
            continue
        total += 1

        if args.embedder == "ollama":
            qvec = embed_with_ollama(q, base_url=args.ollama_url)
        else:
            qvec = embed_with_siliconflow(q, model=args.sf_model)
        results = search_recommendations(conn, qvec, top_k=args.top_k)

        expected = str(row[args.expected_procedure_col]).strip() if has_expected else ""

        print("\n=== Query #{} ===".format(total))
        print(q)
        if has_expected:
            print(f"Expected: {expected}")
        for i, r in enumerate(results, 1):
            print(f"  {i}. {r['procedure_name_zh']} ({r['modality']}) sim={r['similarity']:.4f}")

        if has_expected and expected:
            names = [r["procedure_name_zh"] for r in results]
            if len(names) > 0 and names[0] == expected:
                top1_hits += 1
            if expected in names:
                topk_hits += 1

    conn.close()

    t1 = time.time()
    print("\n==== Summary ====")
    print(f"Evaluated: {total} queries; elapsed: {(t1 - t0):.2f}s")
    if has_expected and total:
        print(f"Top-1 accuracy: {top1_hits / total:.3f}")
        print(f"Top-{args.top_k} hit rate: {topk_hits / total:.3f}")


if __name__ == "__main__":
    sys.exit(main())
