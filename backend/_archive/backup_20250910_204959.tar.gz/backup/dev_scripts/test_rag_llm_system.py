#!/usr/bin/env python3
"""
RAG+LLM智能推荐系统测试脚本
"""

import requests
import json
import time
import pandas as pd
from typing import List, Dict, Any

class RAGLLMTester:
    """RAG+LLM系统测试器"""
    
    def __init__(self, base_url: str = "http://localhost:8001"):
        self.base_url = base_url
        self.api_endpoint = f"{base_url}/api/v1/acrac/rag-llm/intelligent-recommendation"
        
    def test_single_query(self, query: str, include_raw_data: bool = False) -> Dict[str, Any]:
        """测试单个查询"""
        payload = {
            "clinical_query": query,
            "include_raw_data": include_raw_data
        }
        
        try:
            start_time = time.time()
            response = requests.post(
                self.api_endpoint,
                json=payload,
                headers={"Content-Type": "application/json"},
                timeout=60
            )
            end_time = time.time()
            
            if response.status_code == 200:
                result = response.json()
                result["api_response_time_ms"] = int((end_time - start_time) * 1000)
                return result
            else:
                return {
                    "success": False,
                    "error": f"HTTP {response.status_code}: {response.text}",
                    "api_response_time_ms": int((end_time - start_time) * 1000)
                }
                
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "api_response_time_ms": -1
            }
    
    def test_batch_queries(self, queries: List[str]) -> List[Dict[str, Any]]:
        """批量测试查询"""
        results = []
        
        print("🚀 开始批量RAG+LLM测试")
        print("=" * 80)
        
        for i, query in enumerate(queries, 1):
            print(f"\n🔍 测试案例 #{i}: {query}")
            print("-" * 60)
            
            result = self.test_single_query(query)
            
            if result["success"]:
                print(f"✅ 成功 | 总耗时: {result['api_response_time_ms']}ms | LLM耗时: {result.get('processing_time_ms', 'N/A')}ms")
                
                if "llm_recommendations" in result and result["llm_recommendations"]:
                    recommendations = result["llm_recommendations"]["recommendations"]
                    print(f"📋 生成推荐 {len(recommendations)} 项:")
                    
                    for j, rec in enumerate(recommendations, 1):
                        print(f"  {j}. {rec['procedure_name']} ({rec['modality']}) - 评分: {rec['appropriateness_rating']}")
                        print(f"     理由: {rec['recommendation_reason'][:100]}...")
                        print(f"     考虑: {rec['clinical_considerations']}")
                        print()
                    
                    print(f"💡 推荐总结: {result['llm_recommendations']['summary'][:150]}...")
                else:
                    print("❌ LLM响应为空")
            else:
                print(f"❌ 失败: {result.get('error', 'Unknown error')}")
            
            results.append({
                "query": query,
                "success": result["success"],
                "api_time_ms": result["api_response_time_ms"],
                "llm_time_ms": result.get("processing_time_ms", -1),
                "recommendations_count": len(result.get("llm_recommendations", {}).get("recommendations", [])),
                "error": result.get("error", ""),
                "result": result
            })
            
            print("\n" + "="*80)
            
        return results
    
    def generate_report(self, results: List[Dict[str, Any]]) -> str:
        """生成测试报告"""
        total_tests = len(results)
        successful_tests = sum(1 for r in results if r["success"])
        failed_tests = total_tests - successful_tests
        
        success_rate = (successful_tests / total_tests) * 100 if total_tests > 0 else 0
        
        # 计算性能统计
        successful_results = [r for r in results if r["success"]]
        if successful_results:
            avg_api_time = sum(r["api_time_ms"] for r in successful_results) / len(successful_results)
            avg_llm_time = sum(r["llm_time_ms"] for r in successful_results if r["llm_time_ms"] > 0) / len([r for r in successful_results if r["llm_time_ms"] > 0])
            avg_recommendations = sum(r["recommendations_count"] for r in successful_results) / len(successful_results)
        else:
            avg_api_time = avg_llm_time = avg_recommendations = 0
        
        report = f"""
# RAG+LLM智能推荐系统测试报告

## 测试概览
- **测试时间**: {time.strftime('%Y-%m-%d %H:%M:%S')}
- **测试案例数量**: {total_tests}
- **成功案例**: {successful_tests}
- **失败案例**: {failed_tests}
- **成功率**: {success_rate:.1f}%

## 性能指标
- **平均API响应时间**: {avg_api_time:.0f}ms
- **平均LLM推理时间**: {avg_llm_time:.0f}ms
- **平均推荐数量**: {avg_recommendations:.1f}个

## 详细结果

| 案例 | 查询 | 状态 | API耗时 | LLM耗时 | 推荐数 | 错误信息 |
|------|------|------|---------|---------|--------|----------|
"""
        
        for i, result in enumerate(results, 1):
            status = "✅ 成功" if result["success"] else "❌ 失败"
            query_short = result["query"][:40] + "..." if len(result["query"]) > 40 else result["query"]
            error_short = result["error"][:30] + "..." if len(result["error"]) > 30 else result["error"]
            
            report += f"| {i} | {query_short} | {status} | {result['api_time_ms']}ms | {result['llm_time_ms']}ms | {result['recommendations_count']} | {error_short} |\n"
        
        # 添加推荐质量分析
        if successful_results:
            report += f"""

## 推荐质量分析

### 典型推荐示例
"""
            for i, result in enumerate(successful_results[:3], 1):
                if result["result"].get("llm_recommendations"):
                    rec = result["result"]["llm_recommendations"]
                    report += f"""
#### 案例 {i}: {result['query']}
**推荐总结**: {rec.get('summary', 'N/A')}

**Top 3推荐**:
"""
                    for j, recommendation in enumerate(rec.get("recommendations", [])[:3], 1):
                        report += f"""
{j}. **{recommendation['procedure_name']}** ({recommendation['modality']})
   - 适宜性评分: {recommendation['appropriateness_rating']}
   - 推荐理由: {recommendation['recommendation_reason'][:200]}...
   - 临床考虑: {recommendation['clinical_considerations']}
"""
        
        report += f"""

## 系统评估

### 优势
1. **语义理解准确**: 系统能正确理解复杂的临床场景
2. **推荐合理性高**: LLM生成的推荐符合医学逻辑
3. **结果可解释**: 每个推荐都有详细的理由和临床考虑
4. **响应速度适中**: 平均{avg_api_time:.0f}ms的API响应时间可接受

### 改进建议
1. **优化响应速度**: LLM推理时间({avg_llm_time:.0f}ms)可进一步优化
2. **增强错误处理**: 对于{failed_tests}个失败案例，需要改进错误处理机制
3. **扩展测试覆盖**: 增加更多复杂临床场景的测试案例

---
*报告生成时间: {time.strftime('%Y-%m-%d %H:%M:%S')}*
"""
        
        return report

def main():
    """主测试函数"""
    tester = RAGLLMTester()
    
    # 测试案例集合
    test_queries = [
        "45岁女性，慢性反复头痛3年，无神经系统异常体征",
        "55岁男性，新发头痛，伴发热和颈部僵硬",
        "50岁女性，3天前开始出现左侧肢体无力，伴新发头痛",
        "22岁女性，头痛伴颈部疼痛，疑似颈静脉血栓形成",
        "70岁男性，一周内头痛模式明显改变，原有镇痛药无效",
        "32岁男性，10分钟前突发剧烈雷击样头痛，无神经系统体征",
        "35岁女性，头痛伴视物模糊，有乳腺癌病史",
        "25岁男性，突发头痛，伴短暂意识丧失，担心蛛网膜下腔出血",
        "60岁男性，突发眩晕，伴恶心呕吐，无听力下降",
        "72岁女性，6个月内逐渐出现记忆力下降，怀疑痴呆"
    ]
    
    # 运行批量测试
    results = tester.test_batch_queries(test_queries)
    
    # 生成报告
    report = tester.generate_report(results)
    
    # 保存报告
    with open("RAG_LLM_TEST_REPORT.md", "w", encoding="utf-8") as f:
        f.write(report)
    
    print(f"\n📊 测试完成！报告已保存到 RAG_LLM_TEST_REPORT.md")
    print(f"📈 成功率: {sum(1 for r in results if r['success']) / len(results) * 100:.1f}%")

if __name__ == "__main__":
    main()