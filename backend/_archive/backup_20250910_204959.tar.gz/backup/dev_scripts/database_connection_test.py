#!/usr/bin/env python3
"""
数据库连接测试脚本

测试连接Docker中的PostgreSQL数据库并进行向量搜索功能测试
"""

import sys
import os
import time
import logging
from typing import Dict, Any, Optional, List
import json
from datetime import datetime

# 添加项目根目录到path
sys.path.append('/Users/charlieliu/git_project_vscode/09_medical/ACRAC-web/backend')

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DatabaseConnectionTester:
    """数据库连接测试器"""
    
    def __init__(self):
        self.test_results = {
            "timestamp": datetime.now().isoformat(),
            "tests": {},
            "summary": {}
        }
        
    def test_basic_imports(self) -> Dict[str, Any]:
        """测试基本导入"""
        logger.info("测试基本模块导入...")
        
        result = {
            "test_name": "基本模块导入",
            "success": True,
            "imports": {},
            "errors": []
        }
        
        # 测试核心导入
        import_tests = [
            ("psycopg2", "PostgreSQL驱动"),
            ("sqlalchemy", "SQLAlchemy ORM"),
            ("requests", "HTTP请求库"),
            ("app.core.config", "项目配置"),
            ("app.core.database", "数据库配置"),
            ("app.models.acrac_models", "数据模型")
        ]
        
        for module_name, description in import_tests:
            try:
                if module_name.startswith("app."):
                    __import__(module_name, fromlist=[''])
                else:
                    __import__(module_name)
                result["imports"][module_name] = {
                    "success": True,
                    "description": description
                }
                logger.info(f"  ✅ {description} ({module_name})")
            except Exception as e:
                result["imports"][module_name] = {
                    "success": False,
                    "error": str(e),
                    "description": description
                }
                result["success"] = False
                result["errors"].append(f"{module_name}: {str(e)}")
                logger.error(f"  ❌ {description} ({module_name}): {str(e)}")
        
        return result
    
    def test_database_connection(self) -> Dict[str, Any]:
        """测试数据库连接"""
        logger.info("测试数据库连接...")
        
        result = {
            "test_name": "数据库连接",
            "connection_configs": [],
            "successful_connection": None,
            "success": False,
            "error": None
        }
        
        # 多种数据库连接配置
        connection_configs = [
            {
                "name": "Docker PostgreSQL (默认)",
                "url": "postgresql://postgres:password@localhost:5432/acrac_db"
            },
            {
                "name": "Docker PostgreSQL (备用端口)",
                "url": "postgresql://postgres:password@localhost:5433/acrac_db"
            },
            {
                "name": "本地PostgreSQL",
                "url": "postgresql://postgres:password@127.0.0.1:5432/acrac_db"
            }
        ]
        
        for config in connection_configs:
            logger.info(f"  尝试连接: {config['name']}")
            try:
                import psycopg2
                from urllib.parse import urlparse
                
                # 解析连接URL
                parsed = urlparse(config["url"])
                conn = psycopg2.connect(
                    host=parsed.hostname,
                    port=parsed.port or 5432,
                    database=parsed.path[1:],  # 去掉开头的 /
                    user=parsed.username,
                    password=parsed.password
                )
                
                # 测试连接
                cursor = conn.cursor()
                cursor.execute("SELECT 1")
                cursor.fetchone()
                cursor.close()
                conn.close()
                
                config_result = {
                    "name": config["name"],
                    "url": config["url"],
                    "success": True,
                    "error": None
                }
                result["connection_configs"].append(config_result)
                result["successful_connection"] = config
                result["success"] = True
                
                logger.info(f"    ✅ 连接成功: {config['name']}")
                break  # 成功连接后退出循环
                
            except Exception as e:
                config_result = {
                    "name": config["name"],
                    "url": config["url"],
                    "success": False,
                    "error": str(e)
                }
                result["connection_configs"].append(config_result)
                logger.warning(f"    ❌ 连接失败: {config['name']} - {str(e)}")
        
        if not result["success"]:
            result["error"] = "所有数据库连接配置都失败"
            logger.error("❌ 所有数据库连接尝试都失败")
        
        return result
    
    def test_pgvector_extension(self, db_url: str) -> Dict[str, Any]:
        """测试pgvector扩展"""
        logger.info("测试pgvector扩展...")
        
        result = {
            "test_name": "pgvector扩展",
            "extension_installed": False,
            "vector_support": False,
            "success": False,
            "error": None
        }
        
        try:
            import psycopg2
            from urllib.parse import urlparse
            
            # 连接数据库
            parsed = urlparse(db_url)
            conn = psycopg2.connect(
                host=parsed.hostname,
                port=parsed.port or 5432,
                database=parsed.path[1:],
                user=parsed.username,
                password=parsed.password
            )
            
            cursor = conn.cursor()
            
            # 检查pgvector扩展
            cursor.execute("SELECT * FROM pg_extension WHERE extname = 'vector'")
            extensions = cursor.fetchall()
            
            if extensions:
                result["extension_installed"] = True
                logger.info("  ✅ pgvector扩展已安装")
                
                # 测试向量操作
                try:
                    cursor.execute("SELECT '[1,2,3]'::vector")
                    cursor.fetchone()
                    result["vector_support"] = True
                    result["success"] = True
                    logger.info("  ✅ 向量操作支持正常")
                except Exception as e:
                    result["error"] = f"向量操作测试失败: {str(e)}"
                    logger.error(f"  ❌ 向量操作测试失败: {str(e)}")
            else:
                result["error"] = "pgvector扩展未安装"
                logger.error("  ❌ pgvector扩展未安装")
            
            cursor.close()
            conn.close()
            
        except Exception as e:
            result["error"] = str(e)
            logger.error(f"  ❌ pgvector测试失败: {str(e)}")
        
        return result
    
    def test_tables_existence(self, db_url: str) -> Dict[str, Any]:
        """测试表是否存在"""
        logger.info("测试数据表存在性...")
        
        result = {
            "test_name": "数据表存在性",
            "tables": {},
            "total_tables": 0,
            "existing_tables": 0,
            "success": False,
            "error": None
        }
        
        expected_tables = [
            "panels",
            "topics",
            "clinical_scenarios", 
            "procedure_dictionary",
            "clinical_recommendations"
        ]
        
        try:
            import psycopg2
            from urllib.parse import urlparse
            
            # 连接数据库
            parsed = urlparse(db_url)
            conn = psycopg2.connect(
                host=parsed.hostname,
                port=parsed.port or 5432,
                database=parsed.path[1:],
                user=parsed.username,
                password=parsed.password
            )
            
            cursor = conn.cursor()
            
            for table in expected_tables:
                try:
                    # 检查表是否存在
                    cursor.execute("""
                        SELECT EXISTS (
                            SELECT FROM information_schema.tables 
                            WHERE table_schema = 'public' 
                            AND table_name = %s
                        )
                    """, (table,))
                    
                    exists = cursor.fetchone()[0]
                    
                    if exists:
                        # 获取记录数
                        cursor.execute(f"SELECT COUNT(*) FROM {table}")
                        count = cursor.fetchone()[0]
                        
                        # 检查是否有向量字段
                        cursor.execute("""
                            SELECT column_name FROM information_schema.columns 
                            WHERE table_name = %s AND column_name = 'embedding'
                        """, (table,))
                        
                        has_embedding = bool(cursor.fetchall())
                        
                        result["tables"][table] = {
                            "exists": True,
                            "record_count": count,
                            "has_embedding": has_embedding
                        }
                        result["existing_tables"] += 1
                        logger.info(f"  ✅ {table}: {count}条记录" + (", 有向量字段" if has_embedding else ""))
                        
                    else:
                        result["tables"][table] = {
                            "exists": False,
                            "record_count": 0,
                            "has_embedding": False
                        }
                        logger.warning(f"  ❌ {table}: 表不存在")
                        
                except Exception as e:
                    result["tables"][table] = {
                        "exists": False,
                        "error": str(e)
                    }
                    logger.error(f"  ❌ {table}: 检查失败 - {str(e)}")
            
            result["total_tables"] = len(expected_tables)
            result["success"] = result["existing_tables"] > 0
            
            cursor.close()
            conn.close()
            
            logger.info(f"表存在性检查完成: {result['existing_tables']}/{result['total_tables']}个表存在")
            
        except Exception as e:
            result["error"] = str(e)
            logger.error(f"❌ 表存在性测试失败: {str(e)}")
        
        return result
    
    def test_vector_search_capability(self, db_url: str) -> Dict[str, Any]:
        """测试向量搜索能力"""
        logger.info("测试向量搜索能力...")
        
        result = {
            "test_name": "向量搜索能力",
            "vector_generation": False,
            "vector_search": False,
            "search_results": [],
            "success": False,
            "error": None
        }
        
        try:
            # 测试向量生成
            from app.services.vector_search_service import SiliconFlowEmbedder
            
            embedder = SiliconFlowEmbedder()
            test_text = "测试文本"
            
            logger.info("  测试向量生成...")
            embedding = embedder.generate_embedding(test_text)
            
            if embedding and len(embedding) == 1024:
                result["vector_generation"] = True
                logger.info(f"  ✅ 向量生成成功 - 维度: {len(embedding)}")
                
                # 测试向量搜索
                try:
                    import psycopg2
                    from urllib.parse import urlparse
                    
                    parsed = urlparse(db_url)
                    conn = psycopg2.connect(
                        host=parsed.hostname,
                        port=parsed.port or 5432,
                        database=parsed.path[1:],
                        user=parsed.username,
                        password=parsed.password
                    )
                    
                    cursor = conn.cursor()
                    
                    # 检查是否有数据进行向量搜索
                    cursor.execute("SELECT COUNT(*) FROM clinical_recommendations WHERE embedding IS NOT NULL")
                    vector_count = cursor.fetchone()[0]
                    
                    if vector_count > 0:
                        logger.info(f"  发现 {vector_count} 条有向量的推荐记录")
                        
                        # 执行向量搜索测试
                        vector_str = '[' + ','.join(map(str, embedding)) + ']'
                        cursor.execute(f"""
                            SELECT semantic_id, 
                                   (1 - (embedding <=> '{vector_str}'::vector)) as similarity
                            FROM clinical_recommendations 
                            WHERE embedding IS NOT NULL 
                            ORDER BY embedding <=> '{vector_str}'::vector 
                            LIMIT 3
                        """)
                        
                        search_results = cursor.fetchall()
                        
                        for semantic_id, similarity in search_results:
                            result["search_results"].append({
                                "semantic_id": semantic_id,
                                "similarity": float(similarity)
                            })
                        
                        result["vector_search"] = True
                        result["success"] = True
                        logger.info(f"  ✅ 向量搜索成功 - 找到 {len(search_results)} 条结果")
                        
                        # 显示搜索结果
                        for i, (semantic_id, similarity) in enumerate(search_results, 1):
                            logger.info(f"    {i}. {semantic_id}: 相似度 {similarity:.4f}")
                            
                    else:
                        result["error"] = "数据库中没有向量数据"
                        logger.warning("  ⚠️ 数据库中没有向量数据")
                    
                    cursor.close()
                    conn.close()
                    
                except Exception as e:
                    result["error"] = f"向量搜索测试失败: {str(e)}"
                    logger.error(f"  ❌ 向量搜索测试失败: {str(e)}")
                    
            else:
                result["error"] = f"向量生成失败 - 维度: {len(embedding) if embedding else 0}"
                logger.error(f"  ❌ 向量生成失败 - 维度: {len(embedding) if embedding else 0}")
                
        except Exception as e:
            result["error"] = str(e)
            logger.error(f"❌ 向量搜索能力测试失败: {str(e)}")
        
        return result
    
    def run_all_tests(self) -> Dict[str, Any]:
        """运行所有测试"""
        logger.info("🚀 开始数据库连接和向量搜索测试")
        logger.info("=" * 60)
        
        # 1. 基本导入测试
        logger.info("\n1️⃣ 基本模块导入测试")
        self.test_results["tests"]["imports"] = self.test_basic_imports()
        
        # 2. 数据库连接测试  
        logger.info("\n2️⃣ 数据库连接测试")
        db_connection_result = self.test_database_connection()
        self.test_results["tests"]["database_connection"] = db_connection_result
        
        if not db_connection_result["success"]:
            logger.error("❌ 数据库连接失败，跳过后续测试")
            logger.info("\n💡 请确保数据库已启动:")
            logger.info("  docker run -d --name acrac_postgres \\")
            logger.info("    -e POSTGRES_USER=postgres \\")
            logger.info("    -e POSTGRES_PASSWORD=password \\")
            logger.info("    -e POSTGRES_DB=acrac_db \\")
            logger.info("    -p 5432:5432 \\")
            logger.info("    pgvector/pgvector:pg15")
            
            self._generate_summary()
            return self.test_results
        
        # 使用成功的数据库连接进行后续测试
        db_url = db_connection_result["successful_connection"]["url"]
        
        # 3. pgvector扩展测试
        logger.info("\n3️⃣ pgvector扩展测试")
        self.test_results["tests"]["pgvector"] = self.test_pgvector_extension(db_url)
        
        # 4. 表存在性测试
        logger.info("\n4️⃣ 数据表存在性测试")
        self.test_results["tests"]["tables"] = self.test_tables_existence(db_url)
        
        # 5. 向量搜索能力测试
        logger.info("\n5️⃣ 向量搜索能力测试")
        self.test_results["tests"]["vector_search"] = self.test_vector_search_capability(db_url)
        
        # 生成测试摘要
        self._generate_summary()
        
        return self.test_results
    
    def _generate_summary(self):
        """生成测试摘要"""
        logger.info("\n" + "=" * 60)
        logger.info("📊 测试摘要")
        logger.info("=" * 60)
        
        total_tests = len(self.test_results["tests"])
        successful_tests = sum(1 for test in self.test_results["tests"].values() if test.get("success", False))
        
        self.test_results["summary"] = {
            "total_tests": total_tests,
            "successful_tests": successful_tests,
            "success_rate": (successful_tests / total_tests * 100) if total_tests > 0 else 0,
            "overall_status": "成功" if successful_tests == total_tests else "部分成功" if successful_tests > 0 else "失败"
        }
        
        # 输出各项测试结果
        for test_name, test_result in self.test_results["tests"].items():
            status = "✅" if test_result.get("success", False) else "❌"
            logger.info(f"{status} {test_result.get('test_name', test_name)}")
        
        logger.info(f"\n📈 总体结果: {successful_tests}/{total_tests} 测试通过")
        logger.info(f"📊 成功率: {self.test_results['summary']['success_rate']:.1f}%")
        logger.info(f"🎯 状态: {self.test_results['summary']['overall_status']}")
        
        # 保存测试结果
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_file = f"database_test_results_{timestamp}.json"
        
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(self.test_results, f, ensure_ascii=False, indent=2)
        
        logger.info(f"\n💾 测试结果已保存到: {output_file}")

def main():
    """主函数"""
    tester = DatabaseConnectionTester()
    results = tester.run_all_tests()
    return results

if __name__ == "__main__":
    main()