#!/usr/bin/env python3
"""
测试可配置RAG+LLM系统
验证新增的灵活性配置参数
"""

import requests
import json
import time
from typing import Dict, Any

class ConfigurableRAGLLMTester:
    """可配置RAG+LLM系统测试器"""
    
    def __init__(self, base_url: str = "http://localhost:8001"):
        self.base_url = base_url
        self.api_endpoint = f"{base_url}/api/v1/acrac/rag-llm/intelligent-recommendation"
        
    def test_configurable_request(self, query: str, **config_params) -> Dict[str, Any]:
        """测试带配置参数的查询"""
        payload = {
            "clinical_query": query,
            "include_raw_data": True,
            "debug_mode": True,
            **config_params  # 传入配置参数
        }
        
        try:
            start_time = time.time()
            response = requests.post(
                self.api_endpoint,
                json=payload,
                headers={"Content-Type": "application/json"},
                timeout=120
            )
            end_time = time.time()
            
            if response.status_code == 200:
                result = response.json()
                result["api_response_time_ms"] = int((end_time - start_time) * 1000)
                return result
            else:
                return {
                    "success": False,
                    "error": f"HTTP {response.status_code}: {response.text}",
                    "api_response_time_ms": int((end_time - start_time) * 1000)
                }
                
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "api_response_time_ms": -1
            }
    
    def print_config_test_result(self, config_name: str, result: Dict[str, Any], config_params: Dict):
        """打印配置测试结果"""
        if not result.get("success"):
            print(f"❌ {config_name} 测试失败: {result.get('error', 'Unknown error')}")
            return
        
        print(f"🔧 {config_name} 测试结果:")
        print("=" * 60)
        
        # 基本信息
        print(f"📋 配置参数: {config_params}")
        print(f"   响应时间: {result.get('api_response_time_ms', 'N/A')}ms")
        print(f"   相似度阈值: {result.get('similarity_threshold', 'N/A')}")
        print(f"   最高相似度: {result.get('max_similarity', 'N/A'):.3f}")
        print(f"   推理模式: {'RAG' if not result.get('is_low_similarity_mode') else 'No-RAG'}")
        
        # 调试信息分析
        debug_info = result.get("debug_info", {})
        if debug_info:
            print(f"\n🔍 配置效果验证:")
            
            # 验证场景数量配置
            if "step_5_scenarios_with_recs" in debug_info:
                scenarios_info = debug_info["step_5_scenarios_with_recs"]
                actual_scenarios = scenarios_info.get("scenarios_count", 0)
                print(f"   实际场景数: {actual_scenarios}")
                
                # 验证推荐数量配置
                scenarios_summary = scenarios_info.get("scenarios_summary", [])
                if scenarios_summary:
                    total_recs = sum(s.get("recommendations_count", 0) for s in scenarios_summary)
                    print(f"   总推荐数: {total_recs}")
                    for i, s in enumerate(scenarios_summary[:3], 1):
                        print(f"     场景{i}: {s.get('recommendations_count', 0)}个推荐")
            
            # 验证提示词长度
            prompt_length = debug_info.get("step_6_prompt_length", 0)
            print(f"   提示词长度: {prompt_length} 字符")
        
        # 显示场景详情（验证配置效果）
        scenarios_with_recs = result.get("scenarios_with_recommendations", [])
        if scenarios_with_recs:
            print(f"\n📊 实际输出验证:")
            for i, scenario in enumerate(scenarios_with_recs, 1):
                rec_count = len(scenario.get("recommendations", []))
                print(f"   场景{i}: [{scenario['scenario_id']}] - {rec_count}个推荐")
        
        print("\n" + "=" * 60 + "\n")

def main():
    """主测试函数"""
    tester = ConfigurableRAGLLMTester()
    
    # 基础查询
    base_query = "45岁女性，慢性反复头痛3年，无神经系统异常体征"
    
    print("🚀 可配置RAG+LLM系统测试")
    print("=" * 80)
    print(f"测试查询: {base_query}")
    print("=" * 80)
    
    # 测试配置案例
    test_configs = [
        {
            "name": "默认配置",
            "params": {},
            "description": "使用系统默认配置"
        },
        {
            "name": "显示更多场景",
            "params": {"top_scenarios": 3},
            "description": "显示Top 3场景（默认2个）"
        },
        {
            "name": "更多推荐项目",
            "params": {"top_scenarios": 2, "top_recommendations_per_scenario": 5},
            "description": "每个场景显示5个推荐（默认3个）"
        },
        {
            "name": "隐藏推荐理由",
            "params": {"show_reasoning": False},
            "description": "不显示推荐理由，减少提示词长度"
        },
        {
            "name": "降低相似度阈值",
            "params": {"similarity_threshold": 0.5},
            "description": "降低阈值到0.5（默认0.6）"
        },
        {
            "name": "极简配置",
            "params": {
                "top_scenarios": 1, 
                "top_recommendations_per_scenario": 2,
                "show_reasoning": False
            },
            "description": "最小化配置：1个场景，2个推荐，无理由"
        },
        {
            "name": "详细配置",
            "params": {
                "top_scenarios": 3,
                "top_recommendations_per_scenario": 4, 
                "show_reasoning": True,
                "similarity_threshold": 0.4
            },
            "description": "详细配置：3个场景，4个推荐，显示理由，低阈值"
        }
    ]
    
    # 执行测试
    for i, config in enumerate(test_configs, 1):
        print(f"🔍 测试 #{i}: {config['name']}")
        print(f"📝 描述: {config['description']}")
        print("-" * 60)
        
        # 执行测试
        result = tester.test_configurable_request(base_query, **config['params'])
        
        # 打印结果
        tester.print_config_test_result(config['name'], result, config['params'])
        
        # 等待一段时间避免API限制
        time.sleep(1)
    
    # 测试低相似度场景（无RAG模式）
    print("🔍 特殊测试: 无RAG模式触发")
    print("-" * 60)
    low_sim_result = tester.test_configurable_request(
        "如何做番茄炒蛋", 
        similarity_threshold=0.8  # 提高阈值，确保触发无RAG模式
    )
    tester.print_config_test_result("无RAG模式", low_sim_result, {"similarity_threshold": 0.8})
    
    print("✅ 所有配置测试完成！")
    print("\n💡 配置参数总结:")
    print("   • top_scenarios: 控制显示的场景数量 (1-10)")
    print("   • top_recommendations_per_scenario: 控制每个场景的推荐数量 (1-10)")
    print("   • show_reasoning: 控制是否显示推荐理由 (true/false)")
    print("   • similarity_threshold: 控制相似度阈值 (0.1-0.9)")

if __name__ == "__main__":
    main()