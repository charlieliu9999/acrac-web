#!/usr/bin/env python3
"""
测试优化后的提示词内容
直接调用优化后的prepare_llm_prompt方法
"""

import os
import sys
sys.path.append('/Users/charlieliu/git_project_vscode/09_medical/ACRAC-web/backend')

from app.services.rag_llm_recommendation_service import RAGLLMRecommendationService

def test_optimized_prompt():
    """测试优化后的提示词"""
    
    print("🔍 优化后提示词测试")
    print("=" * 80)
    
    # 创建服务实例
    service = RAGLLMRecommendationService()
    
    # 模拟场景数据
    query = "45岁女性，慢性反复头痛3年，无神经系统异常体征"
    
    # 模拟向量搜索结果
    scenarios = [
        {"similarity": 0.634, "semantic_id": "S0823"},
        {"similarity": 0.620, "semantic_id": "S0827"}
    ]
    
    # 模拟场景推荐数据
    scenarios_with_recs = [
        {
            "scenario_id": "S0823",
            "scenario_description": "原发性三叉神经自主神经性头痛（如丛集性头痛）。初始影像学检查。",
            "panel_name": "神经内科",
            "topic_name": "头痛",
            "patient_population": None,
            "risk_level": None,
            "age_group": None,
            "gender": None,
            "urgency_level": None,
            "recommendations": [
                {
                    "procedure_name_zh": "MR颅脑(平扫+增强)",
                    "procedure_name_en": "MRI Head Without and With IV Contrast",
                    "modality": "MRI",
                    "body_part": "头部",
                    "appropriateness_rating": "8",
                    "appropriateness_category_zh": "通常适宜",
                    "reasoning_zh": "头部MRI平扫+增强是TACs初步影像学评估最常用的推荐方法，有助于排除鞍区或后颅窝占位引起的继发性头痛。结构性病变（尤其是垂体来源）仍是TACs最常见的继发性病因，特别是丛集性头痛。"
                }
            ]
        },
        {
            "scenario_id": "S0827",
            "scenario_description": "伴以下任一警示征的头痛：频率或严重程度增加、发热或神经功能缺损、癌症史或免疫功能低下、发病年龄较大50岁或创伤后发病。初始影像学检查",
            "panel_name": "神经内科", 
            "topic_name": "头痛",
            "patient_population": None,
            "risk_level": None,
            "age_group": None,
            "gender": None,
            "urgency_level": None,
            "recommendations": [
                {
                    "procedure_name_zh": "MR颅脑(平扫+增强)",
                    "procedure_name_en": "MRI Head Without and With IV Contrast",
                    "modality": "MRI",
                    "body_part": "头部", 
                    "appropriateness_rating": "9",
                    "appropriateness_category_zh": "通常适宜",
                    "reasoning_zh": "头部MRI平扫+增强扫描可用于伴有上述一项或多项危险信号头痛的初步影像学评估，这些信号提示存在颅内神经病变的可能性较高。"
                },
                {
                    "procedure_name_zh": "CT颅脑(平扫)",
                    "procedure_name_en": "CT Head Without IV Contrast",
                    "modality": "CT",
                    "body_part": "头部",
                    "appropriateness_rating": "7", 
                    "appropriateness_category_zh": "可能适宜",
                    "reasoning_zh": "不注射静脉造影剂的头部CT可用于伴有以下一种或多种警示征象的头痛患者的初步影像学评估。"
                },
                {
                    "procedure_name_zh": "MR颅脑(平扫)",
                    "procedure_name_en": "MRI Head Without IV Contrast",
                    "modality": "MRI", 
                    "body_part": "头部",
                    "appropriateness_rating": "7",
                    "appropriateness_category_zh": "可能适宜",
                    "reasoning_zh": "不进行静脉注射造影剂的头部MRI检查，对于伴有以下一项或多项警示征象的头痛患者，可作为初步影像学评估手段。"
                }
            ]
        }
    ]
    
    # 测试RAG模式提示词
    print("📝 RAG模式提示词 (优化后):")
    print("-" * 60)
    rag_prompt = service.prepare_llm_prompt(query, scenarios, scenarios_with_recs, is_low_similarity=False)
    print(rag_prompt)
    print("\n" + "=" * 80)
    
    # 统计信息
    print(f"📊 优化后统计:")
    print(f"   长度: {len(rag_prompt)} 字符")
    print(f"   场景数: {len(scenarios_with_recs)} 个 → 限制为2个")
    print(f"   推荐数: {sum(len(s.get('recommendations', [])) for s in scenarios_with_recs)} 个")
    
    # 优化效果对比
    print(f"\n💡 优化效果:")
    print(f"   ✅ 移除了空字段 (patient_population, risk_level, age_group, gender, urgency_level)")
    print(f"   ✅ 简化了推荐详情 (只保留核心字段)")
    print(f"   ✅ 压缩了提示词模板")
    print(f"   ✅ 限制推荐理由长度 (最多200字符)")
    
    # 测试无RAG模式提示词
    print(f"\n📝 无RAG模式提示词 (优化后):")
    print("-" * 60)
    no_rag_prompt = service.prepare_llm_prompt("如何做番茄炒蛋", [], [], is_low_similarity=True)
    print(no_rag_prompt)
    print("\n" + "=" * 80)
    
    print(f"📊 无RAG模式统计:")
    print(f"   长度: {len(no_rag_prompt)} 字符")
    print(f"   ✅ 大幅简化，专注核心任务")

if __name__ == "__main__":
    test_optimized_prompt()