#!/usr/bin/env python3
"""
多表向量匹配对比测试脚本

测试用临床场景查询匹配不同表的向量：
1. clinical_scenarios (临床场景) - 语义最相关
2. topics (主题) - 医学主题层面
3. panels (科室) - 科室层面  
4. clinical_recommendations (推荐) - 当前使用的方式

重点验证场景语义匹配的准确性，而非检查项目名称匹配
"""

import os
import sys
import time
import json
import argparse
from typing import Optional, List, Dict
import re

import numpy as np
import pandas as pd
import psycopg2
import requests

try:
    from pgvector.psycopg2 import register_vector
    PGVECTOR_AVAILABLE = True
except Exception:
    PGVECTOR_AVAILABLE = False


def embed_with_siliconflow(text: str, api_key: Optional[str] = None, model: str = "BAAI/bge-m3", timeout: int = 60) -> List[float]:
    api_key = api_key or os.getenv("SILICONFLOW_API_KEY")
    if not api_key:
        print("[warn] SILICONFLOW_API_KEY not set; using random vector")
        return np.random.rand(1024).tolist()
    try:
        headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
        payload = {"model": model, "input": text}
        resp = requests.post("https://api.siliconflow.cn/v1/embeddings", json=payload, headers=headers, timeout=timeout)
        resp.raise_for_status()
        data = resp.json()
        return data["data"][0]["embedding"]
    except Exception as e:
        print(f"[warn] SiliconFlow embedding failed: {e}; using random vector")
        return np.random.rand(1024).tolist()


def connect_db() -> psycopg2.extensions.connection:
    cfg = dict(
        host=os.getenv("PGHOST", "localhost"),
        port=os.getenv("PGPORT", "5432"),
        database=os.getenv("PGDATABASE", "acrac_db"),
        user=os.getenv("PGUSER", "postgres"),
        password=os.getenv("PGPASSWORD", "password"),
    )
    conn = psycopg2.connect(**cfg)
    if PGVECTOR_AVAILABLE:
        register_vector(conn)
    return conn


def search_clinical_scenarios(conn, query_vector: List[float], top_k: int = 5) -> List[Dict]:
    """搜索相似的临床场景"""
    with conn.cursor() as cur:
        if PGVECTOR_AVAILABLE:
            sql = """
                SELECT
                    cs.semantic_id,
                    cs.description_zh,
                    cs.description_en,
                    cs.patient_population,
                    cs.risk_level,
                    cs.age_group,
                    cs.gender,
                    cs.symptom_category,
                    p.name_zh as panel_name,
                    t.name_zh as topic_name,
                    (1 - (cs.embedding <=> %s::vector)) AS similarity
                FROM clinical_scenarios cs
                LEFT JOIN panels p ON cs.panel_id = p.id
                LEFT JOIN topics t ON cs.topic_id = t.id
                WHERE cs.embedding IS NOT NULL
                ORDER BY cs.embedding <=> %s::vector
                LIMIT %s
            """
            cur.execute(sql, (query_vector, query_vector, top_k))
        else:
            vec_str = "[" + ",".join(map(str, query_vector)) + "]"
            sql = f"""
                SELECT
                    cs.semantic_id,
                    cs.description_zh,
                    cs.description_en,
                    cs.patient_population,
                    cs.risk_level,
                    cs.age_group,
                    cs.gender,
                    cs.symptom_category,
                    p.name_zh as panel_name,
                    t.name_zh as topic_name,
                    (1 - (cs.embedding <=> '{vec_str}'::vector)) AS similarity
                FROM clinical_scenarios cs
                LEFT JOIN panels p ON cs.panel_id = p.id
                LEFT JOIN topics t ON cs.topic_id = t.id
                WHERE cs.embedding IS NOT NULL
                ORDER BY cs.embedding <=> '{vec_str}'::vector
                LIMIT {top_k}
            """
            cur.execute(sql)
        rows = cur.fetchall()
    
    results = []
    for r in rows:
        results.append({
            "semantic_id": r[0],
            "description_zh": r[1] or "",
            "description_en": r[2] or "",
            "patient_population": r[3] or "",
            "risk_level": r[4] or "",
            "age_group": r[5] or "",
            "gender": r[6] or "",
            "symptom_category": r[7] or "",
            "panel_name": r[8] or "",
            "topic_name": r[9] or "",
            "similarity": float(r[10])
        })
    return results


def search_topics(conn, query_vector: List[float], top_k: int = 5) -> List[Dict]:
    """搜索相似的医学主题"""
    with conn.cursor() as cur:
        if PGVECTOR_AVAILABLE:
            sql = """
                SELECT
                    t.semantic_id,
                    t.name_zh,
                    t.name_en,
                    t.description,
                    p.name_zh as panel_name,
                    (1 - (t.embedding <=> %s::vector)) AS similarity
                FROM topics t
                LEFT JOIN panels p ON t.panel_id = p.id
                WHERE t.embedding IS NOT NULL
                ORDER BY t.embedding <=> %s::vector
                LIMIT %s
            """
            cur.execute(sql, (query_vector, query_vector, top_k))
        else:
            vec_str = "[" + ",".join(map(str, query_vector)) + "]"
            sql = f"""
                SELECT
                    t.semantic_id,
                    t.name_zh,
                    t.name_en,
                    t.description,
                    p.name_zh as panel_name,
                    (1 - (t.embedding <=> '{vec_str}'::vector)) AS similarity
                FROM topics t
                LEFT JOIN panels p ON t.panel_id = p.id
                WHERE t.embedding IS NOT NULL
                ORDER BY t.embedding <=> '{vec_str}'::vector
                LIMIT {top_k}
            """
            cur.execute(sql)
        rows = cur.fetchall()
    
    results = []
    for r in rows:
        results.append({
            "semantic_id": r[0],
            "name_zh": r[1] or "",
            "name_en": r[2] or "",
            "description": r[3] or "",
            "panel_name": r[4] or "",
            "similarity": float(r[5])
        })
    return results


def search_panels(conn, query_vector: List[float], top_k: int = 5) -> List[Dict]:
    """搜索相似的医学科室"""
    with conn.cursor() as cur:
        if PGVECTOR_AVAILABLE:
            sql = """
                SELECT
                    p.semantic_id,
                    p.name_zh,
                    p.name_en,
                    p.description,
                    (1 - (p.embedding <=> %s::vector)) AS similarity
                FROM panels p
                WHERE p.embedding IS NOT NULL
                ORDER BY p.embedding <=> %s::vector
                LIMIT %s
            """
            cur.execute(sql, (query_vector, query_vector, top_k))
        else:
            vec_str = "[" + ",".join(map(str, query_vector)) + "]"
            sql = f"""
                SELECT
                    p.semantic_id,
                    p.name_zh,
                    p.name_en,
                    p.description,
                    (1 - (p.embedding <=> '{vec_str}'::vector)) AS similarity
                FROM panels p
                WHERE p.embedding IS NOT NULL
                ORDER BY p.embedding <=> '{vec_str}'::vector
                LIMIT {top_k}
            """
            cur.execute(sql)
        rows = cur.fetchall()
    
    results = []
    for r in rows:
        results.append({
            "semantic_id": r[0],
            "name_zh": r[1] or "",
            "name_en": r[2] or "",
            "description": r[3] or "",
            "similarity": float(r[4])
        })
    return results


def search_recommendations(conn, query_vector: List[float], top_k: int = 5) -> List[Dict]:
    """搜索相似的临床推荐（当前方式）"""
    with conn.cursor() as cur:
        if PGVECTOR_AVAILABLE:
            sql = """
                SELECT
                    cr.semantic_id,
                    pd.name_zh AS procedure_name_zh,
                    pd.modality,
                    cr.appropriateness_rating,
                    cr.appropriateness_category_zh,
                    cs.description_zh AS scenario_desc,
                    (1 - (cr.embedding <=> %s::vector)) AS similarity
                FROM clinical_recommendations cr
                JOIN procedure_dictionary pd ON cr.procedure_id = pd.semantic_id
                JOIN clinical_scenarios cs ON cr.scenario_id = cs.semantic_id
                WHERE cr.embedding IS NOT NULL
                ORDER BY cr.embedding <=> %s::vector
                LIMIT %s
            """
            cur.execute(sql, (query_vector, query_vector, top_k))
        else:
            vec_str = "[" + ",".join(map(str, query_vector)) + "]"
            sql = f"""
                SELECT
                    cr.semantic_id,
                    pd.name_zh AS procedure_name_zh,
                    pd.modality,
                    cr.appropriateness_rating,
                    cr.appropriateness_category_zh,
                    cs.description_zh AS scenario_desc,
                    (1 - (cr.embedding <=> '{vec_str}'::vector)) AS similarity
                FROM clinical_recommendations cr
                JOIN procedure_dictionary pd ON cr.procedure_id = pd.semantic_id
                JOIN clinical_scenarios cs ON cr.scenario_id = cs.semantic_id
                WHERE cr.embedding IS NOT NULL
                ORDER BY cr.embedding <=> '{vec_str}'::vector
                LIMIT {top_k}
            """
            cur.execute(sql)
        rows = cur.fetchall()
    
    results = []
    for r in rows:
        results.append({
            "semantic_id": r[0],
            "procedure_name_zh": r[1] or "",
            "modality": r[2] or "",
            "appropriateness_rating": r[3],
            "appropriateness_category_zh": r[4] or "",
            "scenario_desc": r[5] or "",
            "similarity": float(r[6])
        })
    return results


def semantic_similarity_score(query: str, result_text: str) -> float:
    """计算语义相似度评分（中文医学优化版本）"""
    import re
    
    # 中文医学关键词
    medical_terms = {
        '头痛', '发热', '颈部', '僵硬', '慢性', '急性', '男性', '女性',
        '岁', '年', '神经', '系统', '症状', '体征', '检查', '异常', '正常',
        '反复', '新发', '伴', '不伴', '警示征', '初始', '影像学',
        '偏头痛', '紧张型', '原发性', '频率', '严重程度', '增加',
        '无力', '肢体', '左侧', '右侧', '天前', '开始', '出现'
    }
    
    # 提取医学关键词
    def extract_medical_terms(text):
        found_terms = set()
        text_clean = re.sub(r'[^\u4e00-\u9fff\w\s]', '', text)
        for term in medical_terms:
            if term in text_clean:
                found_terms.add(term)
        return found_terms
    
    # 提取数字信息
    def extract_numbers(text):
        numbers = set(re.findall(r'\d+', text))
        return numbers
    
    # 提取年龄性别信息  
    def extract_demographics(text):
        demographics = set()
        if re.search(r'\d+岁', text):
            age_match = re.search(r'(\d+)岁', text)
            if age_match:
                demographics.add(f"{age_match.group(1)}岁")
        if '男性' in text:
            demographics.add('男性')
        if '女性' in text:
            demographics.add('女性')
        return demographics
    
    # 提取特征
    query_medical = extract_medical_terms(query)
    result_medical = extract_medical_terms(result_text)
    query_numbers = extract_numbers(query)
    result_numbers = extract_numbers(result_text)
    query_demo = extract_demographics(query)
    result_demo = extract_demographics(result_text)
    
    # 计算各类匹配
    medical_intersection = query_medical.intersection(result_medical)
    number_intersection = query_numbers.intersection(result_numbers)
    demo_intersection = query_demo.intersection(result_demo)
    
    # 计算总体相似度
    total_query_features = len(query_medical) + len(query_numbers) + len(query_demo)
    total_result_features = len(result_medical) + len(result_numbers) + len(result_demo)
    total_matches = len(medical_intersection) + len(number_intersection) + len(demo_intersection)
    
    if total_query_features == 0 or total_result_features == 0:
        return 0.0
    
    # 使用调和平均数计算相似度
    precision = total_matches / total_result_features if total_result_features > 0 else 0
    recall = total_matches / total_query_features if total_query_features > 0 else 0
    
    if precision + recall == 0:
        return 0.0
    
    f1_score = 2 * (precision * recall) / (precision + recall)
    
    # 特殊加分：如果关键医学词匹配度高
    if '头痛' in medical_intersection:
        f1_score += 0.1
    if '神经' in medical_intersection and '系统' in medical_intersection:
        f1_score += 0.1
        
    return min(1.0, f1_score)


def main():
    ap = argparse.ArgumentParser(description="多表向量匹配对比测试")
    ap.add_argument("--excel-path", required=True, help="Excel测试文件路径")
    ap.add_argument("--query-col", default="临床场景", help="查询列名")
    ap.add_argument("--top-k", type=int, default=5, help="返回结果数量")
    ap.add_argument("--limit", type=int, default=10, help="测试案例数量限制(0=全部)")
    args = ap.parse_args()

    # 加载测试数据
    df = pd.read_excel(args.excel_path)
    if args.query_col not in df.columns:
        raise ValueError(f"未找到列 '{args.query_col}'，可用列: {list(df.columns)}")

    conn = connect_db()
    
    print("🔍 多表向量匹配对比测试")
    print("=" * 80)
    print(f"测试目标: 对比不同表向量匹配临床场景的语义准确性")
    print(f"测试表: clinical_scenarios, topics, panels, clinical_recommendations")
    print("=" * 80)

    for idx, row in df.iterrows():
        if args.limit and idx >= args.limit:
            break
        
        query = str(row[args.query_col]).strip()
        if not query:
            continue
        
        print(f"\n🏥 测试案例 #{idx + 1}")
        print(f"临床场景: {query}")
        print("-" * 60)
        
        # 生成查询向量
        query_vector = embed_with_siliconflow(query)
        
        # 1. 搜索临床场景 (最相关)
        print("📋 1. 临床场景匹配 (clinical_scenarios)")
        scenarios = search_clinical_scenarios(conn, query_vector, args.top_k)
        for i, s in enumerate(scenarios, 1):
            semantic_score = semantic_similarity_score(query, s["description_zh"])
            print(f"  {i}. [{s['semantic_id']}] {s['description_zh'][:60]}...")
            print(f"     相似度: {s['similarity']:.4f} | 语义匹配: {semantic_score:.3f}")
            print(f"     科室: {s['panel_name']} | 主题: {s['topic_name']}")
            if s['patient_population']:
                print(f"     人群: {s['patient_population']} | 症状: {s['symptom_category']}")
            print()
        
        # 2. 搜索医学主题
        print("📚 2. 医学主题匹配 (topics)")
        topics = search_topics(conn, query_vector, args.top_k)
        for i, t in enumerate(topics, 1):
            semantic_score = semantic_similarity_score(query, t["name_zh"])
            print(f"  {i}. [{t['semantic_id']}] {t['name_zh']}")
            print(f"     相似度: {t['similarity']:.4f} | 语义匹配: {semantic_score:.3f}")
            print(f"     科室: {t['panel_name']}")
            if t['description']:
                print(f"     描述: {t['description'][:50]}...")
            print()
        
        # 3. 搜索医学科室  
        print("🏥 3. 医学科室匹配 (panels)")
        panels = search_panels(conn, query_vector, args.top_k)
        for i, p in enumerate(panels, 1):
            semantic_score = semantic_similarity_score(query, p["name_zh"])
            print(f"  {i}. [{p['semantic_id']}] {p['name_zh']}")
            print(f"     相似度: {p['similarity']:.4f} | 语义匹配: {semantic_score:.3f}")
            if p['description']:
                print(f"     描述: {p['description'][:50]}...")
            print()
        
        # 4. 搜索临床推荐 (当前方式)
        print("💊 4. 临床推荐匹配 (clinical_recommendations) - 当前方式")
        recommendations = search_recommendations(conn, query_vector, args.top_k)
        for i, r in enumerate(recommendations, 1):
            semantic_score = semantic_similarity_score(query, r["scenario_desc"])
            print(f"  {i}. [{r['semantic_id']}] {r['procedure_name_zh']} ({r['modality']})")
            print(f"     相似度: {r['similarity']:.4f} | 语义匹配: {semantic_score:.3f}")
            print(f"     评分: {r['appropriateness_rating']} | 类别: {r['appropriateness_category_zh']}")
            print(f"     场景: {r['scenario_desc'][:50]}...")
            print()
        
        # 语义匹配对比分析
        print("📊 语义匹配分析:")
        
        # 计算各表的平均相似度和语义匹配度
        scenario_avg_sim = sum(s['similarity'] for s in scenarios) / len(scenarios) if scenarios else 0
        scenario_avg_semantic = sum(semantic_similarity_score(query, s["description_zh"]) for s in scenarios) / len(scenarios) if scenarios else 0
        
        topic_avg_sim = sum(t['similarity'] for t in topics) / len(topics) if topics else 0
        topic_avg_semantic = sum(semantic_similarity_score(query, t["name_zh"]) for t in topics) / len(topics) if topics else 0
        
        panel_avg_sim = sum(p['similarity'] for p in panels) / len(panels) if panels else 0
        panel_avg_semantic = sum(semantic_similarity_score(query, p["name_zh"]) for p in panels) / len(panels) if panels else 0
        
        rec_avg_sim = sum(r['similarity'] for r in recommendations) / len(recommendations) if recommendations else 0
        rec_avg_semantic = sum(semantic_similarity_score(query, r["scenario_desc"]) for r in recommendations) / len(recommendations) if recommendations else 0
        
        print(f"  临床场景: 平均相似度 {scenario_avg_sim:.4f} | 平均语义匹配 {scenario_avg_semantic:.3f}")
        print(f"  医学主题: 平均相似度 {topic_avg_sim:.4f} | 平均语义匹配 {topic_avg_semantic:.3f}")
        print(f"  医学科室: 平均相似度 {panel_avg_sim:.4f} | 平均语义匹配 {panel_avg_semantic:.3f}")
        print(f"  临床推荐: 平均相似度 {rec_avg_sim:.4f} | 平均语义匹配 {rec_avg_semantic:.3f}")
        
        # 推荐最佳匹配方式
        semantic_scores = {
            "临床场景": scenario_avg_semantic,
            "医学主题": topic_avg_semantic, 
            "医学科室": panel_avg_semantic,
            "临床推荐": rec_avg_semantic
        }
        
        best_match = max(semantic_scores.items(), key=lambda x: x[1])
        print(f"  🎯 最佳语义匹配: {best_match[0]} (语义分数: {best_match[1]:.3f})")
        
        print("=" * 80)
    
    conn.close()
    
    print("\n🎉 多表向量匹配对比测试完成")
    print("\n💡 建议:")
    print("1. 如果临床场景匹配度最高，建议优先使用 clinical_scenarios 表进行语义搜索")
    print("2. 如果医学主题匹配度较好，可以考虑分层搜索：先匹配主题，再匹配场景")
    print("3. 临床推荐匹配用于最终的检查项目推荐，但不适合语义相似度判断")
    print("4. 可以组合使用多表结果，提供更全面的推荐")


if __name__ == "__main__":
    main()