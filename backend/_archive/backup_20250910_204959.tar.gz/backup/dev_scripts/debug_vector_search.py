#!/usr/bin/env python3
"""
调试向量搜索问题
"""

import psycopg2
import os
import pandas as pd
from pgvector.psycopg2 import register_vector
import sys
sys.path.append('.')
from evaluate_vector_search_from_excel import embed_with_siliconflow

def debug_vector_search():
    # 连接数据库
    conn = psycopg2.connect(
        host='localhost',
        port='5432', 
        database='acrac_db',
        user='postgres',
        password='password'
    )
    register_vector(conn)

    # 读取测试数据
    df = pd.read_excel('../影像测试样例-0318-1.xlsx')
    print(f"测试数据行数: {len(df)}")
    print(f"列名: {list(df.columns)}")
    
    # 查看前几个测试案例
    print("\n前3个测试案例:")
    for i in range(min(3, len(df))):
        scenario = df.iloc[i]['临床场景']
        expected = df.iloc[i]['首选检查项目（标准化）']
        print(f"案例 {i+1}:")
        print(f"  场景: {scenario}")
        print(f"  期望: {expected}")
        
        # 生成查询向量
        query_vector = embed_with_siliconflow(scenario)
        print(f"  向量维度: {len(query_vector)}")
        
        # 搜索最相似的推荐
        with conn.cursor() as cur:
            sql = """
                SELECT
                    cr.semantic_id,
                    pd.name_zh AS procedure_name_zh,
                    pd.name_en AS procedure_name_en,
                    pd.modality,
                    (1 - (cr.embedding <=> %s::vector)) AS similarity
                FROM clinical_recommendations cr
                JOIN procedure_dictionary pd ON cr.procedure_id = pd.semantic_id
                WHERE cr.embedding IS NOT NULL
                ORDER BY cr.embedding <=> %s::vector
                LIMIT 5
            """
            cur.execute(sql, (query_vector, query_vector))
            results = cur.fetchall()
            
            print(f"  搜索结果:")
            for j, result in enumerate(results):
                print(f"    {j+1}. {result[1]} ({result[3]}) - 相似度: {result[4]:.4f}")
                
                # 检查是否匹配期望结果
                if expected in result[1] or result[1] in expected:
                    print(f"    *** 匹配! ***")
        
        print()

    conn.close()

if __name__ == "__main__":
    debug_vector_search()
