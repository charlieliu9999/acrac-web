#!/usr/bin/env python3
"""
API端点测试脚本
测试所有FastAPI端点的正确性
"""
import requests
import json
import time
from typing import Dict, Any

class APITester:
    """API测试器"""
    
    def __init__(self, base_url: str = "http://localhost:8000"):
        self.base_url = base_url
        self.session = requests.Session()
    
    def test_health_endpoints(self):
        """测试健康检查端点"""
        print("🔍 测试健康检查端点...")
        
        endpoints = [
            "/health",
            "/api/v1/acrac/vector/v2/health"
        ]
        
        for endpoint in endpoints:
            try:
                response = self.session.get(f"{self.base_url}{endpoint}")
                if response.status_code == 200:
                    print(f"✅ {endpoint}: {response.json()}")
                else:
                    print(f"❌ {endpoint}: {response.status_code}")
            except Exception as e:
                print(f"❌ {endpoint}: {e}")
    
    def test_database_stats(self):
        """测试数据库统计端点"""
        print("\n🔍 测试数据库统计端点...")
        
        try:
            response = self.session.get(f"{self.base_url}/api/v1/acrac/vector/v2/stats")
            if response.status_code == 200:
                stats = response.json()
                print("✅ 数据库统计:")
                for key, value in stats.items():
                    print(f"  {key}: {value}")
            else:
                print(f"❌ 数据库统计: {response.status_code}")
        except Exception as e:
            print(f"❌ 数据库统计: {e}")
    
    def test_vector_search(self):
        """测试向量搜索端点"""
        print("\n🔍 测试向量搜索端点...")
        
        test_queries = [
            "胸部CT检查",
            "心脏MRI扫描",
            "孕妇影像检查",
            "头痛诊断",
            "肿瘤筛查"
        ]
        
        for query in test_queries:
            print(f"\n📝 测试查询: '{query}'")
            
            # 测试综合搜索
            self._test_comprehensive_search(query)
            
            # 测试单独搜索
            self._test_individual_searches(query)
    
    def _test_comprehensive_search(self, query: str):
        """测试综合搜索"""
        try:
            payload = {
                "query_text": query,
                "top_k": 3,
                "similarity_threshold": 0.0
            }
            
            response = self.session.post(
                f"{self.base_url}/api/v1/acrac/vector/v2/search/comprehensive",
                json=payload
            )
            
            if response.status_code == 200:
                result = response.json()
                print(f"  ✅ 综合搜索: {result['search_time_ms']}ms, {result['total_results']}个结果")
                
                # 显示各类结果数量
                print(f"    科室: {len(result['panels'])}")
                print(f"    主题: {len(result['topics'])}")
                print(f"    场景: {len(result['scenarios'])}")
                print(f"    检查项目: {len(result['procedures'])}")
                print(f"    推荐: {len(result['recommendations'])}")
            else:
                print(f"  ❌ 综合搜索: {response.status_code} - {response.text}")
        except Exception as e:
            print(f"  ❌ 综合搜索: {e}")
    
    def _test_individual_searches(self, query: str):
        """测试单独搜索"""
        search_types = [
            ("科室", "panels"),
            ("主题", "topics"),
            ("场景", "scenarios"),
            ("检查项目", "procedures"),
            ("推荐", "recommendations")
        ]
        
        payload = {
            "query_text": query,
            "top_k": 2,
            "similarity_threshold": 0.0
        }
        
        for name, endpoint in search_types:
            try:
                response = self.session.post(
                    f"{self.base_url}/api/v1/acrac/vector/v2/search/{endpoint}",
                    json=payload
                )
                
                if response.status_code == 200:
                    results = response.json()
                    print(f"    ✅ {name}: {len(results)}个结果")
                    
                    # 显示前2个结果的相似度
                    for i, result in enumerate(results[:2]):
                        if 'similarity_score' in result:
                            print(f"      {i+1}. 相似度: {result['similarity_score']:.4f}")
                else:
                    print(f"    ❌ {name}: {response.status_code}")
            except Exception as e:
                print(f"    ❌ {name}: {e}")
    
    def test_error_handling(self):
        """测试错误处理"""
        print("\n🔍 测试错误处理...")
        
        # 测试空查询
        try:
            payload = {"query_text": "", "top_k": 5}
            response = self.session.post(
                f"{self.base_url}/api/v1/acrac/vector/v2/search/comprehensive",
                json=payload
            )
            print(f"  空查询: {response.status_code}")
        except Exception as e:
            print(f"  空查询: {e}")
        
        # 测试无效参数
        try:
            payload = {"query_text": "测试", "top_k": 100, "similarity_threshold": 2.0}
            response = self.session.post(
                f"{self.base_url}/api/v1/acrac/vector/v2/search/comprehensive",
                json=payload
            )
            print(f"  无效参数: {response.status_code}")
        except Exception as e:
            print(f"  无效参数: {e}")
    
    def test_performance(self):
        """测试性能"""
        print("\n🔍 测试性能...")
        
        query = "胸部CT检查"
        payload = {
            "query_text": query,
            "top_k": 10,
            "similarity_threshold": 0.0
        }
        
        # 执行多次请求测试性能
        times = []
        for i in range(5):
            start_time = time.time()
            try:
                response = self.session.post(
                    f"{self.base_url}/api/v1/acrac/vector/v2/search/comprehensive",
                    json=payload
                )
                end_time = time.time()
                
                if response.status_code == 200:
                    times.append(end_time - start_time)
                    print(f"  请求 {i+1}: {(end_time - start_time)*1000:.2f}ms")
                else:
                    print(f"  请求 {i+1}: 失败 - {response.status_code}")
            except Exception as e:
                print(f"  请求 {i+1}: 错误 - {e}")
        
        if times:
            avg_time = sum(times) / len(times)
            print(f"  平均响应时间: {avg_time*1000:.2f}ms")
    
    def run_all_tests(self):
        """运行所有测试"""
        print("🚀 开始API端点测试")
        print("=" * 50)
        
        # 检查服务是否运行
        try:
            response = self.session.get(f"{self.base_url}/health")
            if response.status_code != 200:
                print("❌ 服务未运行，请先启动FastAPI服务")
                return
        except Exception as e:
            print(f"❌ 无法连接到服务: {e}")
            return
        
        # 运行测试
        self.test_health_endpoints()
        self.test_database_stats()
        self.test_vector_search()
        self.test_error_handling()
        self.test_performance()
        
        print("\n✅ API端点测试完成！")

def main():
    """主函数"""
    tester = APITester()
    tester.run_all_tests()

if __name__ == "__main__":
    main()
