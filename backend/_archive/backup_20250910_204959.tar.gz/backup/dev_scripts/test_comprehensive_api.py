"""
API端点综合测试脚本

测试所有API端点的完整功能：
1. ACRAC简化API
2. 智能分析API  
3. 三种方法API
4. 向量搜索API V1 & V2
5. 端到端测试场景
"""

import asyncio
import json
import time
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime
import aiohttp

from tests.test_config import get_test_config, get_api_endpoints

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class ComprehensiveAPITester:
    """综合API测试器"""
    
    def __init__(self):
        self.config = get_test_config()
        self.endpoints = get_api_endpoints()
        self.base_url = self.config["api_base_url"]
        self.session: Optional[aiohttp.ClientSession] = None
        
    async def __aenter__(self):
        """异步上下文管理器入口"""
        timeout = aiohttp.ClientTimeout(total=self.config["timeout"])
        self.session = aiohttp.ClientSession(timeout=timeout)
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """异步上下文管理器出口"""
        if self.session:
            await self.session.close()
    
    async def test_acrac_simple_api(self) -> Dict[str, Any]:
        """测试ACRAC简化API"""
        logger.info("测试ACRAC简化API")
        
        results = {
            "search": [],
            "recommend": [],
            "analyze": []
        }
        
        # 测试搜索功能
        for query in self.config["test_queries"][:3]:
            try:
                url = f"{self.base_url}{self.endpoints['acrac_simple']['search']}"
                payload = {
                    "query": query,
                    "limit": 10,
                    "threshold": 0.7
                }
                
                start_time = time.time()
                async with self.session.post(url, json=payload) as response:
                    response_time = (time.time() - start_time) * 1000
                    data = await response.json()
                    
                    result = {
                        "query": query,
                        "status_code": response.status,
                        "response_time_ms": round(response_time, 2),
                        "success": response.status == 200,
                        "results_count": len(data.get("results", [])) if response.status == 200 else 0,
                        "error": None if response.status == 200 else data
                    }
                    
                    results["search"].append(result)
                    
                    if result["success"]:
                        logger.info(f"  ✅ 搜索查询 '{query[:20]}...' - {result['results_count']}条结果")
                    else:
                        logger.error(f"  ❌ 搜索查询失败: {result['error']}")
                        
            except Exception as e:
                logger.error(f"  ❌ 搜索查询异常: {str(e)}")
                results["search"].append({
                    "query": query,
                    "status_code": None,
                    "response_time_ms": None,
                    "success": False,
                    "results_count": 0,
                    "error": str(e)
                })
        
        # 测试推荐功能
        test_query = self.config["test_queries"][0]
        try:
            url = f"{self.base_url}{self.endpoints['acrac_simple']['recommend']}"
            payload = {
                "clinical_description": test_query,
                "patient_info": {
                    "age": 45,
                    "gender": "女性",
                    "pregnancy_status": "非妊娠期"
                },
                "limit": 5
            }
            
            start_time = time.time()
            async with self.session.post(url, json=payload) as response:
                response_time = (time.time() - start_time) * 1000
                data = await response.json()
                
                result = {
                    "status_code": response.status,
                    "response_time_ms": round(response_time, 2),
                    "success": response.status == 200,
                    "recommendations_count": len(data.get("recommendations", [])) if response.status == 200 else 0,
                    "error": None if response.status == 200 else data
                }
                
                results["recommend"].append(result)
                
                if result["success"]:
                    logger.info(f"  ✅ 推荐功能 - {result['recommendations_count']}条推荐")
                else:
                    logger.error(f"  ❌ 推荐功能失败: {result['error']}")
                    
        except Exception as e:
            logger.error(f"  ❌ 推荐功能异常: {str(e)}")
            results["recommend"].append({
                "status_code": None,
                "response_time_ms": None,
                "success": False,
                "recommendations_count": 0,
                "error": str(e)
            })
        
        # 测试分析功能
        try:
            url = f"{self.base_url}{self.endpoints['acrac_simple']['analyze']}"
            payload = {
                "text": test_query,
                "analysis_type": "comprehensive"
            }
            
            start_time = time.time()
            async with self.session.post(url, json=payload) as response:
                response_time = (time.time() - start_time) * 1000
                data = await response.json()
                
                result = {
                    "status_code": response.status,
                    "response_time_ms": round(response_time, 2),
                    "success": response.status == 200,
                    "analysis_results": data if response.status == 200 else None,
                    "error": None if response.status == 200 else data
                }
                
                results["analyze"].append(result)
                
                if result["success"]:
                    logger.info(f"  ✅ 分析功能成功")
                else:
                    logger.error(f"  ❌ 分析功能失败: {result['error']}")
                    
        except Exception as e:
            logger.error(f"  ❌ 分析功能异常: {str(e)}")
            results["analyze"].append({
                "status_code": None,
                "response_time_ms": None,
                "success": False,
                "analysis_results": None,
                "error": str(e)
            })
        
        return results
    
    async def test_intelligent_analysis_api(self) -> Dict[str, Any]:
        """测试智能分析API"""
        logger.info("测试智能分析API")
        
        results = {
            "analyze": [],
            "recommend": []
        }
        
        test_query = self.config["test_queries"][0]
        
        # 测试智能分析
        try:
            url = f"{self.base_url}{self.endpoints['intelligent_analysis']['analyze']}"
            payload = {
                "clinical_query": test_query,
                "analysis_depth": "comprehensive",
                "include_reasoning": True
            }
            
            start_time = time.time()
            async with self.session.post(url, json=payload) as response:
                response_time = (time.time() - start_time) * 1000
                data = await response.json()
                
                result = {
                    "status_code": response.status,
                    "response_time_ms": round(response_time, 2),
                    "success": response.status == 200,
                    "analysis_data": data if response.status == 200 else None,
                    "error": None if response.status == 200 else data
                }
                
                results["analyze"].append(result)
                
                if result["success"]:
                    logger.info(f"  ✅ 智能分析成功")
                else:
                    logger.error(f"  ❌ 智能分析失败: {result['error']}")
                    
        except Exception as e:
            logger.error(f"  ❌ 智能分析异常: {str(e)}")
            results["analyze"].append({
                "status_code": None,
                "response_time_ms": None,
                "success": False,
                "analysis_data": None,
                "error": str(e)
            })
        
        # 测试智能推荐
        try:
            url = f"{self.base_url}{self.endpoints['intelligent_analysis']['recommend']}"
            payload = {
                "clinical_scenario": test_query,
                "patient_profile": {
                    "age": 45,
                    "gender": "女性"
                },
                "preference_weights": {
                    "accuracy": 0.4,
                    "safety": 0.3,
                    "cost": 0.2,
                    "accessibility": 0.1
                }
            }
            
            start_time = time.time()
            async with self.session.post(url, json=payload) as response:
                response_time = (time.time() - start_time) * 1000
                data = await response.json()
                
                result = {
                    "status_code": response.status,
                    "response_time_ms": round(response_time, 2),
                    "success": response.status == 200,
                    "recommendations": data if response.status == 200 else None,
                    "error": None if response.status == 200 else data
                }
                
                results["recommend"].append(result)
                
                if result["success"]:
                    logger.info(f"  ✅ 智能推荐成功")
                else:
                    logger.error(f"  ❌ 智能推荐失败: {result['error']}")
                    
        except Exception as e:
            logger.error(f"  ❌ 智能推荐异常: {str(e)}")
            results["recommend"].append({
                "status_code": None,
                "response_time_ms": None,
                "success": False,
                "recommendations": None,
                "error": str(e)
            })
        
        return results
    
    async def test_three_methods_api(self) -> Dict[str, Any]:
        """测试三种方法API"""
        logger.info("测试三种方法API")
        
        results = {
            "recommend": [],
            "compare": []
        }
        
        test_query = self.config["test_queries"][0]
        
        # 测试三种方法推荐
        try:
            url = f"{self.base_url}{self.endpoints['three_methods']['recommend']}"
            payload = {
                "clinical_query": test_query,
                "methods": ["vector_similarity", "keyword_matching", "rule_based"],
                "top_k": 5
            }
            
            start_time = time.time()
            async with self.session.post(url, json=payload) as response:
                response_time = (time.time() - start_time) * 1000
                data = await response.json()
                
                result = {
                    "status_code": response.status,
                    "response_time_ms": round(response_time, 2),
                    "success": response.status == 200,
                    "methods_results": data if response.status == 200 else None,
                    "error": None if response.status == 200 else data
                }
                
                results["recommend"].append(result)
                
                if result["success"]:
                    logger.info(f"  ✅ 三种方法推荐成功")
                    # 记录每种方法的结果数
                    if "methods_results" in data:
                        for method, method_data in data["methods_results"].items():
                            count = len(method_data.get("recommendations", []))
                            logger.info(f"    {method}: {count}条推荐")
                else:
                    logger.error(f"  ❌ 三种方法推荐失败: {result['error']}")
                    
        except Exception as e:
            logger.error(f"  ❌ 三种方法推荐异常: {str(e)}")
            results["recommend"].append({
                "status_code": None,
                "response_time_ms": None,
                "success": False,
                "methods_results": None,
                "error": str(e)
            })
        
        # 测试方法比较
        try:
            url = f"{self.base_url}{self.endpoints['three_methods']['compare']}"
            payload = {
                "clinical_query": test_query,
                "comparison_metrics": ["accuracy", "speed", "coverage"],
                "benchmark_scenarios": [test_query]
            }
            
            start_time = time.time()
            async with self.session.post(url, json=payload) as response:
                response_time = (time.time() - start_time) * 1000
                data = await response.json()
                
                result = {
                    "status_code": response.status,
                    "response_time_ms": round(response_time, 2),
                    "success": response.status == 200,
                    "comparison_results": data if response.status == 200 else None,
                    "error": None if response.status == 200 else data
                }
                
                results["compare"].append(result)
                
                if result["success"]:
                    logger.info(f"  ✅ 方法比较成功")
                else:
                    logger.error(f"  ❌ 方法比较失败: {result['error']}")
                    
        except Exception as e:
            logger.error(f"  ❌ 方法比较异常: {str(e)}")
            results["compare"].append({
                "status_code": None,
                "response_time_ms": None,
                "success": False,
                "comparison_results": None,
                "error": str(e)
            })
        
        return results
    
    async def test_end_to_end_scenarios(self) -> Dict[str, Any]:
        """测试端到端场景"""
        logger.info("测试端到端临床场景")
        
        # 定义完整的临床场景
        clinical_scenarios = [
            {
                "name": "急性头痛患者",
                "description": "45岁女性，突发剧烈头痛2小时，伴恶心呕吐",
                "patient_info": {
                    "age": 45,
                    "gender": "女性",
                    "chief_complaint": "突发剧烈头痛",
                    "duration": "2小时",
                    "associated_symptoms": ["恶心", "呕吐"]
                },
                "expected_procedures": ["头颅CT", "头颅MRI"]
            },
            {
                "name": "胸痛患者",
                "description": "55岁男性，胸痛3天，活动后加重，伴气促",
                "patient_info": {
                    "age": 55,
                    "gender": "男性",
                    "chief_complaint": "胸痛",
                    "duration": "3天",
                    "triggers": ["活动后加重"],
                    "associated_symptoms": ["气促"]
                },
                "expected_procedures": ["胸片", "心电图", "冠脉CTA"]
            },
            {
                "name": "腹痛患者",
                "description": "30岁女性，右下腹痛6小时，伴发热",
                "patient_info": {
                    "age": 30,
                    "gender": "女性",
                    "chief_complaint": "右下腹痛",
                    "duration": "6小时",
                    "location": "右下腹",
                    "associated_symptoms": ["发热"]
                },
                "expected_procedures": ["腹部CT", "腹部超声"]
            }
        ]
        
        results = []
        
        for scenario in clinical_scenarios:
            logger.info(f"  测试场景: {scenario['name']}")
            
            scenario_result = {
                "scenario_name": scenario["name"],
                "description": scenario["description"],
                "patient_info": scenario["patient_info"],
                "expected_procedures": scenario["expected_procedures"],
                "api_results": {},
                "overall_success": False,
                "found_expected_procedures": [],
                "unexpected_procedures": []
            }
            
            # 测试向量搜索V2综合搜索
            try:
                url = f"{self.base_url}{self.endpoints['vector_search_v2']['comprehensive']}"
                payload = {
                    "query_text": scenario["description"],
                    "top_k": 10,
                    "similarity_threshold": 0.3
                }
                
                async with self.session.post(url, json=payload) as response:
                    if response.status == 200:
                        data = await response.json()
                        scenario_result["api_results"]["vector_search_v2"] = {
                            "success": True,
                            "recommendations_count": len(data.get("recommendations", [])),
                            "top_procedures": [
                                rec.get("procedure_name", "") 
                                for rec in data.get("recommendations", [])[:5]
                            ]
                        }
                        
                        # 检查是否找到期望的检查项目
                        found_procedures = []
                        all_procedures = [rec.get("procedure_name", "") for rec in data.get("recommendations", [])]
                        
                        for expected in scenario["expected_procedures"]:
                            for found in all_procedures:
                                if expected.lower() in found.lower() or found.lower() in expected.lower():
                                    found_procedures.append(found)
                                    break
                        
                        scenario_result["found_expected_procedures"] = found_procedures
                        
                    else:
                        scenario_result["api_results"]["vector_search_v2"] = {
                            "success": False,
                            "error": f"HTTP {response.status}"
                        }
                        
            except Exception as e:
                scenario_result["api_results"]["vector_search_v2"] = {
                    "success": False,
                    "error": str(e)
                }
            
            # 测试ACRAC简化推荐
            try:
                url = f"{self.base_url}{self.endpoints['acrac_simple']['recommend']}"
                payload = {
                    "clinical_description": scenario["description"],
                    "patient_info": scenario["patient_info"],
                    "limit": 10
                }
                
                async with self.session.post(url, json=payload) as response:
                    if response.status == 200:
                        data = await response.json()
                        scenario_result["api_results"]["acrac_simple"] = {
                            "success": True,
                            "recommendations_count": len(data.get("recommendations", [])),
                            "top_procedures": [
                                rec.get("procedure_name", "") 
                                for rec in data.get("recommendations", [])[:5]
                            ]
                        }
                    else:
                        scenario_result["api_results"]["acrac_simple"] = {
                            "success": False,
                            "error": f"HTTP {response.status}"
                        }
                        
            except Exception as e:
                scenario_result["api_results"]["acrac_simple"] = {
                    "success": False,
                    "error": str(e)
                }
            
            # 评估整体成功状态
            successful_apis = sum(1 for api_result in scenario_result["api_results"].values() if api_result.get("success", False))
            scenario_result["overall_success"] = successful_apis > 0 and len(scenario_result["found_expected_procedures"]) > 0
            
            if scenario_result["overall_success"]:
                logger.info(f"    ✅ 场景测试成功 - 找到期望检查: {scenario_result['found_expected_procedures']}")
            else:
                logger.info(f"    ⚠️ 场景测试部分成功 - API成功: {successful_apis}, 期望检查: {len(scenario_result['found_expected_procedures'])}")
            
            results.append(scenario_result)
        
        return {
            "scenarios": results,
            "total_scenarios": len(results),
            "successful_scenarios": sum(1 for r in results if r["overall_success"]),
            "success_rate": sum(1 for r in results if r["overall_success"]) / len(results) * 100 if results else 0
        }
    
    async def run_comprehensive_tests(self) -> Dict[str, Any]:
        """运行所有综合测试"""
        logger.info("=" * 60)
        logger.info("开始API端点综合测试")
        logger.info("=" * 60)
        
        start_time = time.time()
        all_results = {
            "test_summary": {
                "start_time": datetime.now().isoformat(),
                "total_time_seconds": 0
            },
            "acrac_simple": None,
            "intelligent_analysis": None,
            "three_methods": None,
            "end_to_end_scenarios": None
        }
        
        # 1. ACRAC简化API测试
        logger.info("\n1. ACRAC简化API测试")
        all_results["acrac_simple"] = await self.test_acrac_simple_api()
        
        # 2. 智能分析API测试
        logger.info("\n2. 智能分析API测试")
        all_results["intelligent_analysis"] = await self.test_intelligent_analysis_api()
        
        # 3. 三种方法API测试
        logger.info("\n3. 三种方法API测试")
        all_results["three_methods"] = await self.test_three_methods_api()
        
        # 4. 端到端场景测试
        logger.info("\n4. 端到端临床场景测试")
        all_results["end_to_end_scenarios"] = await self.test_end_to_end_scenarios()
        
        # 计算总时间
        total_time = time.time() - start_time
        all_results["test_summary"]["end_time"] = datetime.now().isoformat()
        all_results["test_summary"]["total_time_seconds"] = round(total_time, 2)
        
        # 输出测试摘要
        logger.info("\n" + "=" * 60)
        logger.info("API综合测试完成摘要")
        logger.info("=" * 60)
        
        # 统计各API成功率
        acrac_successes = sum(1 for test_group in all_results["acrac_simple"].values() 
                             for test in test_group if test.get("success", False))
        acrac_total = sum(len(test_group) for test_group in all_results["acrac_simple"].values())
        
        intel_successes = sum(1 for test_group in all_results["intelligent_analysis"].values() 
                             for test in test_group if test.get("success", False))
        intel_total = sum(len(test_group) for test_group in all_results["intelligent_analysis"].values())
        
        three_successes = sum(1 for test_group in all_results["three_methods"].values() 
                             for test in test_group if test.get("success", False))
        three_total = sum(len(test_group) for test_group in all_results["three_methods"].values())
        
        e2e_success_rate = all_results["end_to_end_scenarios"]["success_rate"]
        
        logger.info(f"ACRAC简化API: {acrac_successes}/{acrac_total} ({acrac_successes/acrac_total*100:.1f}%)")
        logger.info(f"智能分析API: {intel_successes}/{intel_total} ({intel_successes/intel_total*100:.1f}%)")
        logger.info(f"三种方法API: {three_successes}/{three_total} ({three_successes/three_total*100:.1f}%)")
        logger.info(f"端到端场景: {e2e_success_rate:.1f}%")
        logger.info(f"总耗时: {total_time:.2f}秒")
        
        return all_results

async def main():
    """主函数"""
    async with ComprehensiveAPITester() as tester:
        results = await tester.run_comprehensive_tests()
        
        # 保存测试结果
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_file = f"comprehensive_api_test_results_{timestamp}.json"
        
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(results, f, ensure_ascii=False, indent=2)
        
        logger.info(f"\n测试结果已保存到: {output_file}")
        
        return results

if __name__ == "__main__":
    # 运行综合测试
    results = asyncio.run(main())