"""
向量搜索API连通性和正确性测试

测试所有向量搜索相关的API端点：
1. 基础连通性测试
2. 输入验证测试
3. 返回数据格式测试
4. 向量搜索准确性测试
5. 性能测试
"""

import asyncio
import json
import time
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime
import aiohttp
import pytest

import sys
import os

# 添加项目根目录到path
sys.path.append('/Users/charlieliu/git_project_vscode/09_medical/ACRAC-web/backend')
sys.path.append('/Users/charlieliu/git_project_vscode/09_medical/ACRAC-web/backend/tests')

from test_config import get_test_config, get_api_endpoints, get_validation_config

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class VectorSearchAPITester:
    """向量搜索API测试器"""
    
    def __init__(self):
        self.config = get_test_config()
        self.endpoints = get_api_endpoints()
        self.validation = get_validation_config()
        self.base_url = self.config["api_base_url"]
        self.session: Optional[aiohttp.ClientSession] = None
        self.test_results = []
        
    async def __aenter__(self):
        """异步上下文管理器入口"""
        timeout = aiohttp.ClientTimeout(total=self.config["timeout"])
        self.session = aiohttp.ClientSession(timeout=timeout)
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """异步上下文管理器出口"""
        if self.session:
            await self.session.close()
    
    async def test_health_check(self) -> Dict[str, Any]:
        """测试健康检查端点"""
        test_name = "Health Check"
        logger.info(f"开始测试: {test_name}")
        
        try:
            url = f"{self.base_url}{self.endpoints['health_check']}"
            start_time = time.time()
            
            async with self.session.get(url) as response:
                response_time = (time.time() - start_time) * 1000
                data = await response.json()
                
                result = {
                    "test_name": test_name,
                    "url": url,
                    "status_code": response.status,
                    "response_time_ms": round(response_time, 2),
                    "success": response.status == 200,
                    "data": data,
                    "error": None
                }
                
                if response.status == 200:
                    logger.info(f"✅ {test_name} 通过 - 响应时间: {response_time:.2f}ms")
                else:
                    logger.error(f"❌ {test_name} 失败 - 状态码: {response.status}")
                
                return result
                
        except Exception as e:
            logger.error(f"❌ {test_name} 异常: {str(e)}")
            return {
                "test_name": test_name,
                "url": url,
                "status_code": None,
                "response_time_ms": None,
                "success": False,
                "data": None,
                "error": str(e)
            }
    
    async def test_vector_search_v2_comprehensive(self, query_text: str) -> Dict[str, Any]:
        """测试V2综合向量搜索"""
        test_name = f"Vector Search V2 Comprehensive - '{query_text[:20]}...'"
        logger.info(f"开始测试: {test_name}")
        
        try:
            url = f"{self.base_url}{self.endpoints['vector_search_v2']['comprehensive']}"
            payload = {
                "query_text": query_text,
                "top_k": 5,
                "similarity_threshold": 0.0
            }
            
            start_time = time.time()
            async with self.session.post(url, json=payload) as response:
                response_time = (time.time() - start_time) * 1000
                data = await response.json()
                
                result = {
                    "test_name": test_name,
                    "url": url,
                    "payload": payload,
                    "status_code": response.status,
                    "response_time_ms": round(response_time, 2),
                    "success": response.status == 200,
                    "data": data,
                    "error": None
                }
                
                if response.status == 200:
                    # 验证返回数据结构
                    validation_result = self._validate_comprehensive_response(data)
                    result["validation"] = validation_result
                    
                    if validation_result["valid"]:
                        logger.info(f"✅ {test_name} 通过 - 响应时间: {response_time:.2f}ms")
                        self._log_search_results(data)
                    else:
                        logger.error(f"❌ {test_name} 数据验证失败: {validation_result['errors']}")
                        result["success"] = False
                else:
                    logger.error(f"❌ {test_name} 失败 - 状态码: {response.status}")
                
                return result
                
        except Exception as e:
            logger.error(f"❌ {test_name} 异常: {str(e)}")
            return {
                "test_name": test_name,
                "url": url,
                "payload": payload,
                "status_code": None,
                "response_time_ms": None,
                "success": False,
                "data": None,
                "error": str(e)
            }
    
    async def test_vector_search_entity(self, entity_type: str, query_text: str) -> Dict[str, Any]:
        """测试特定实体类型的向量搜索"""
        test_name = f"Vector Search {entity_type.title()} - '{query_text[:20]}...'"
        logger.info(f"开始测试: {test_name}")
        
        try:
            url = f"{self.base_url}{self.endpoints['vector_search_v2'][entity_type]}"
            payload = {
                "query_text": query_text,
                "top_k": 10,
                "similarity_threshold": 0.0
            }
            
            start_time = time.time()
            async with self.session.post(url, json=payload) as response:
                response_time = (time.time() - start_time) * 1000
                data = await response.json()
                
                result = {
                    "test_name": test_name,
                    "entity_type": entity_type,
                    "url": url,
                    "payload": payload,
                    "status_code": response.status,
                    "response_time_ms": round(response_time, 2),
                    "success": response.status == 200,
                    "data": data,
                    "error": None
                }
                
                if response.status == 200:
                    # 验证返回数据
                    validation_result = self._validate_entity_response(entity_type, data)
                    result["validation"] = validation_result
                    result["results_count"] = len(data) if isinstance(data, list) else 0
                    
                    if validation_result["valid"]:
                        logger.info(f"✅ {test_name} 通过 - {result['results_count']}条结果, 响应时间: {response_time:.2f}ms")
                    else:
                        logger.error(f"❌ {test_name} 数据验证失败: {validation_result['errors']}")
                        result["success"] = False
                else:
                    logger.error(f"❌ {test_name} 失败 - 状态码: {response.status}")
                
                return result
                
        except Exception as e:
            logger.error(f"❌ {test_name} 异常: {str(e)}")
            return {
                "test_name": test_name,
                "entity_type": entity_type,
                "url": url,
                "payload": payload,
                "status_code": None,
                "response_time_ms": None,
                "success": False,
                "data": None,
                "error": str(e)
            }
    
    async def test_database_stats(self) -> Dict[str, Any]:
        """测试数据库统计API"""
        test_name = "Database Statistics"
        logger.info(f"开始测试: {test_name}")
        
        try:
            url = f"{self.base_url}{self.endpoints['vector_search_v2']['stats']}"
            start_time = time.time()
            
            async with self.session.get(url) as response:
                response_time = (time.time() - start_time) * 1000
                data = await response.json()
                
                result = {
                    "test_name": test_name,
                    "url": url,
                    "status_code": response.status,
                    "response_time_ms": round(response_time, 2),
                    "success": response.status == 200,
                    "data": data,
                    "error": None
                }
                
                if response.status == 200:
                    logger.info(f"✅ {test_name} 通过 - 响应时间: {response_time:.2f}ms")
                    self._log_stats(data)
                else:
                    logger.error(f"❌ {test_name} 失败 - 状态码: {response.status}")
                
                return result
                
        except Exception as e:
            logger.error(f"❌ {test_name} 异常: {str(e)}")
            return {
                "test_name": test_name,
                "url": url,
                "status_code": None,
                "response_time_ms": None,
                "success": False,
                "data": None,
                "error": str(e)
            }
    
    async def test_input_validation(self) -> List[Dict[str, Any]]:
        """测试输入验证"""
        logger.info("开始测试输入验证")
        
        test_cases = [
            {
                "name": "空查询文本",
                "payload": {"query_text": "", "top_k": 5},
                "expected_status": 422
            },
            {
                "name": "过长查询文本",
                "payload": {"query_text": "x" * 1001, "top_k": 5},
                "expected_status": 422
            },
            {
                "name": "无效top_k（0）",
                "payload": {"query_text": "测试查询", "top_k": 0},
                "expected_status": 422
            },
            {
                "name": "无效top_k（超限）",
                "payload": {"query_text": "测试查询", "top_k": 51},
                "expected_status": 422
            },
            {
                "name": "无效相似度阈值（负数）",
                "payload": {"query_text": "测试查询", "top_k": 5, "similarity_threshold": -0.1},
                "expected_status": 422
            },
            {
                "name": "无效相似度阈值（超限）",
                "payload": {"query_text": "测试查询", "top_k": 5, "similarity_threshold": 1.1},
                "expected_status": 422
            }
        ]
        
        results = []
        url = f"{self.base_url}{self.endpoints['vector_search_v2']['comprehensive']}"
        
        for test_case in test_cases:
            try:
                async with self.session.post(url, json=test_case["payload"]) as response:
                    result = {
                        "test_name": f"输入验证 - {test_case['name']}",
                        "payload": test_case["payload"],
                        "expected_status": test_case["expected_status"],
                        "actual_status": response.status,
                        "success": response.status == test_case["expected_status"],
                        "error": None
                    }
                    
                    if result["success"]:
                        logger.info(f"✅ 输入验证 - {test_case['name']} 通过")
                    else:
                        logger.error(f"❌ 输入验证 - {test_case['name']} 失败 - 期望: {test_case['expected_status']}, 实际: {response.status}")
                    
                    results.append(result)
                    
            except Exception as e:
                logger.error(f"❌ 输入验证 - {test_case['name']} 异常: {str(e)}")
                results.append({
                    "test_name": f"输入验证 - {test_case['name']}",
                    "payload": test_case["payload"],
                    "expected_status": test_case["expected_status"],
                    "actual_status": None,
                    "success": False,
                    "error": str(e)
                })
        
        return results
    
    async def test_performance(self, query_text: str, concurrent_requests: int = 5) -> Dict[str, Any]:
        """测试性能和并发"""
        test_name = f"Performance Test - {concurrent_requests} concurrent requests"
        logger.info(f"开始测试: {test_name}")
        
        url = f"{self.base_url}{self.endpoints['vector_search_v2']['comprehensive']}"
        payload = {
            "query_text": query_text,
            "top_k": 10,
            "similarity_threshold": 0.0
        }
        
        async def single_request():
            start_time = time.time()
            try:
                async with self.session.post(url, json=payload) as response:
                    await response.json()
                    return {
                        "success": response.status == 200,
                        "response_time": (time.time() - start_time) * 1000,
                        "status_code": response.status
                    }
            except Exception as e:
                return {
                    "success": False,
                    "response_time": (time.time() - start_time) * 1000,
                    "error": str(e)
                }
        
        start_time = time.time()
        tasks = [single_request() for _ in range(concurrent_requests)]
        results = await asyncio.gather(*tasks)
        total_time = (time.time() - start_time) * 1000
        
        successful_requests = [r for r in results if r["success"]]
        failed_requests = [r for r in results if not r["success"]]
        
        if successful_requests:
            response_times = [r["response_time"] for r in successful_requests]
            avg_response_time = sum(response_times) / len(response_times)
            min_response_time = min(response_times)
            max_response_time = max(response_times)
        else:
            avg_response_time = min_response_time = max_response_time = 0
        
        result = {
            "test_name": test_name,
            "concurrent_requests": concurrent_requests,
            "successful_requests": len(successful_requests),
            "failed_requests": len(failed_requests),
            "success_rate": len(successful_requests) / concurrent_requests * 100,
            "total_time_ms": round(total_time, 2),
            "avg_response_time_ms": round(avg_response_time, 2),
            "min_response_time_ms": round(min_response_time, 2),
            "max_response_time_ms": round(max_response_time, 2),
            "requests_per_second": round(concurrent_requests / (total_time / 1000), 2),
            "all_results": results
        }
        
        logger.info(f"✅ {test_name} 完成:")
        logger.info(f"   成功率: {result['success_rate']:.1f}%")
        logger.info(f"   平均响应时间: {result['avg_response_time_ms']:.2f}ms")
        logger.info(f"   吞吐量: {result['requests_per_second']:.2f} req/s")
        
        return result
    
    def _validate_comprehensive_response(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """验证综合搜索响应数据格式"""
        errors = []
        
        # 检查必需字段
        required_fields = ["query_text", "search_time_ms", "panels", "topics", "scenarios", "procedures", "recommendations", "total_results"]
        for field in required_fields:
            if field not in data:
                errors.append(f"缺少字段: {field}")
        
        # 检查数据类型
        if "search_time_ms" in data and not isinstance(data["search_time_ms"], (int, float)):
            errors.append("search_time_ms 应该是数字")
        
        if "total_results" in data and not isinstance(data["total_results"], int):
            errors.append("total_results 应该是整数")
        
        # 检查各实体类型
        for entity_type in ["panels", "topics", "scenarios", "procedures", "recommendations"]:
            if entity_type in data:
                if not isinstance(data[entity_type], list):
                    errors.append(f"{entity_type} 应该是列表")
                else:
                    for i, item in enumerate(data[entity_type]):
                        item_errors = self._validate_entity_item(entity_type[:-1], item)  # 去掉复数s
                        if item_errors:
                            errors.extend([f"{entity_type}[{i}]: {err}" for err in item_errors])
        
        return {
            "valid": len(errors) == 0,
            "errors": errors
        }
    
    def _validate_entity_response(self, entity_type: str, data: List[Dict[str, Any]]) -> Dict[str, Any]:
        """验证实体类型响应数据格式"""
        errors = []
        
        if not isinstance(data, list):
            errors.append("响应应该是列表格式")
            return {"valid": False, "errors": errors}
        
        for i, item in enumerate(data):
            item_errors = self._validate_entity_item(entity_type, item)
            if item_errors:
                errors.extend([f"item[{i}]: {err}" for err in item_errors])
        
        return {
            "valid": len(errors) == 0,
            "errors": errors
        }
    
    def _validate_entity_item(self, entity_type: str, item: Dict[str, Any]) -> List[str]:
        """验证单个实体项目"""
        errors = []
        
        if entity_type in self.validation["required_fields"]:
            required_fields = self.validation["required_fields"][entity_type]
            for field in required_fields:
                if field not in item:
                    errors.append(f"缺少字段: {field}")
        
        # 验证相似度分数
        if "similarity_score" in item:
            score = item["similarity_score"]
            if not isinstance(score, (int, float)):
                errors.append("similarity_score 应该是数字")
            elif not (0.0 <= score <= 1.0):
                errors.append(f"similarity_score 应该在0-1范围内，实际值: {score}")
        
        # 验证适宜性评分
        if "appropriateness_rating" in item and item["appropriateness_rating"] is not None:
            rating = item["appropriateness_rating"]
            if not isinstance(rating, int):
                errors.append("appropriateness_rating 应该是整数")
            elif not (1 <= rating <= 9):
                errors.append(f"appropriateness_rating 应该在1-9范围内，实际值: {rating}")
        
        return errors
    
    def _log_search_results(self, data: Dict[str, Any]):
        """记录搜索结果摘要"""
        logger.info(f"搜索结果摘要:")
        logger.info(f"  查询: {data.get('query_text', 'N/A')}")
        logger.info(f"  搜索耗时: {data.get('search_time_ms', 'N/A')}ms")
        logger.info(f"  科室: {len(data.get('panels', []))}条")
        logger.info(f"  主题: {len(data.get('topics', []))}条")
        logger.info(f"  临床场景: {len(data.get('scenarios', []))}条")
        logger.info(f"  检查项目: {len(data.get('procedures', []))}条")
        logger.info(f"  临床推荐: {len(data.get('recommendations', []))}条")
        logger.info(f"  总结果: {data.get('total_results', 'N/A')}条")
    
    def _log_stats(self, data: Dict[str, Any]):
        """记录数据库统计信息"""
        logger.info("数据库统计信息:")
        for key, value in data.items():
            if key.endswith("_count"):
                logger.info(f"  {key}: {value}")
            elif key.endswith("_coverage"):
                logger.info(f"  {key}: {value:.2%}")
    
    async def run_all_tests(self) -> Dict[str, Any]:
        """运行所有测试"""
        logger.info("=" * 60)
        logger.info("开始向量搜索API全面测试")
        logger.info("=" * 60)
        
        start_time = time.time()
        all_results = {
            "test_summary": {
                "start_time": datetime.now().isoformat(),
                "total_tests": 0,
                "passed_tests": 0,
                "failed_tests": 0,
                "total_time_seconds": 0
            },
            "health_check": None,
            "database_stats": None,
            "comprehensive_searches": [],
            "entity_searches": {},
            "input_validation": [],
            "performance_test": None
        }
        
        # 1. 健康检查
        logger.info("\n1. 健康检查测试")
        all_results["health_check"] = await self.test_health_check()
        
        # 2. 数据库统计
        logger.info("\n2. 数据库统计测试")
        all_results["database_stats"] = await self.test_database_stats()
        
        # 3. 综合搜索测试
        logger.info("\n3. 综合搜索测试")
        for query in self.config["test_queries"][:3]:  # 测试前3个查询
            result = await self.test_vector_search_v2_comprehensive(query)
            all_results["comprehensive_searches"].append(result)
        
        # 4. 各实体类型搜索测试
        logger.info("\n4. 各实体类型搜索测试")
        entity_types = ["panels", "topics", "scenarios", "procedures", "recommendations"]
        test_query = self.config["test_queries"][0]
        
        for entity_type in entity_types:
            logger.info(f"\n4.{entity_types.index(entity_type)+1} {entity_type.title()} 搜索测试")
            result = await self.test_vector_search_entity(entity_type, test_query)
            all_results["entity_searches"][entity_type] = result
        
        # 5. 输入验证测试
        logger.info("\n5. 输入验证测试")
        all_results["input_validation"] = await self.test_input_validation()
        
        # 6. 性能测试
        logger.info("\n6. 性能测试")
        all_results["performance_test"] = await self.test_performance(test_query, 5)
        
        # 计算测试摘要
        total_time = time.time() - start_time
        all_results["test_summary"]["end_time"] = datetime.now().isoformat()
        all_results["test_summary"]["total_time_seconds"] = round(total_time, 2)
        
        # 统计测试结果
        all_tests = []
        all_tests.append(all_results["health_check"])
        all_tests.append(all_results["database_stats"])
        all_tests.extend(all_results["comprehensive_searches"])
        all_tests.extend(all_results["entity_searches"].values())
        all_tests.extend(all_results["input_validation"])
        all_tests.append(all_results["performance_test"])
        
        total_tests = len(all_tests)
        passed_tests = sum(1 for test in all_tests if test and test.get("success", False))
        failed_tests = total_tests - passed_tests
        
        all_results["test_summary"]["total_tests"] = total_tests
        all_results["test_summary"]["passed_tests"] = passed_tests
        all_results["test_summary"]["failed_tests"] = failed_tests
        all_results["test_summary"]["success_rate"] = round(passed_tests / total_tests * 100, 2) if total_tests > 0 else 0
        
        # 输出测试摘要
        logger.info("\n" + "=" * 60)
        logger.info("测试完成摘要")
        logger.info("=" * 60)
        logger.info(f"总测试数: {total_tests}")
        logger.info(f"通过测试: {passed_tests}")
        logger.info(f"失败测试: {failed_tests}")
        logger.info(f"成功率: {all_results['test_summary']['success_rate']:.1f}%")
        logger.info(f"总耗时: {total_time:.2f}秒")
        
        return all_results

# 主测试函数
async def main():
    """主测试函数"""
    async with VectorSearchAPITester() as tester:
        results = await tester.run_all_tests()
        
        # 保存测试结果
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_file = f"test_results_{timestamp}.json"
        
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(results, f, ensure_ascii=False, indent=2)
        
        logger.info(f"\n测试结果已保存到: {output_file}")
        
        return results

if __name__ == "__main__":
    # 运行测试
    results = asyncio.run(main())