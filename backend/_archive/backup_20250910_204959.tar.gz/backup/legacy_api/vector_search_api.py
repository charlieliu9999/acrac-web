"""
向量检索API端点
提供Clinical Scenarios和Recommendations的向量相似度计算功能
"""
import numpy as np
import time
import requests
import logging
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import text
from pydantic import BaseModel, Field

from app.core.database import get_db
from app.services.ollama_qwen_service import OllamaQwenService

logger = logging.getLogger(__name__)

router = APIRouter()

# ==================== 请求和响应模型 ====================

class VectorSearchRequest(BaseModel):
    """向量搜索请求"""
    query_text: str = Field(..., description="患者主诉文本", min_length=1, max_length=1000)
    top_k: int = Field(10, description="返回结果数量", ge=1, le=50)
    similarity_threshold: float = Field(0.0, description="相似度阈值", ge=0.0, le=1.0)

class ScenarioSearchResult(BaseModel):
    """Clinical Scenario搜索结果"""
    description_zh: Optional[str] = None
    description_en: Optional[str] = None
    semantic_id: Optional[str] = None
    variant_type: Optional[str] = None
    similarity_score: float

class RecommendationSearchResult(BaseModel):
    """Clinical Recommendation搜索结果"""
    semantic_id: str
    procedure_name_zh: str
    procedure_modality: Optional[str]
    procedure_body_part: Optional[str]
    appropriateness_rating: Optional[int]
    appropriateness_category_zh: Optional[str]
    reasoning_zh: Optional[str]
    evidence_level: Optional[str]
    pregnancy_safety: Optional[str]
    similarity_score: float
    scenario_description: Optional[str] = None

class VectorSearchResponse(BaseModel):
    """向量搜索响应"""
    query_text: str
    search_time_ms: int
    scenarios: List[ScenarioSearchResult]
    recommendations: List[RecommendationSearchResult]
    total_scenarios_found: int
    total_recommendations_found: int

# ==================== 向量搜索服务 ====================

class VectorSearchService:
    """向量搜索服务"""
    
    def __init__(self, db: Session):
        self.db = db
        self.ollama_service = OllamaQwenService()
    
    def search_scenarios(
        self, 
        query_text: str, 
        top_k: int = 10, 
        similarity_threshold: float = 0.0
    ) -> List[ScenarioSearchResult]:
        """搜索相似的Clinical Scenarios"""
        try:
            # 生成查询向量
            query_vector = self._generate_query_vector(query_text)
            if query_vector is None:
                raise HTTPException(status_code=500, detail="无法生成查询向量")
            
            # 执行向量相似度搜索
            vector_str = '[' + ','.join(map(str, query_vector)) + ']'
            query = text(f"""
                SELECT 
                    v.description_zh,
                    v.description_en,
                    v.semantic_id,
                    v.variant_type,
                    (1 - (v.embedding <=> '{vector_str}'::vector)) as similarity_score
                FROM variants v
                WHERE v.embedding IS NOT NULL
                AND (1 - (v.embedding <=> '{vector_str}'::vector)) >= {similarity_threshold}
                ORDER BY v.embedding <=> '{vector_str}'::vector
                LIMIT {top_k}
            """)
            
            result = self.db.execute(query)
            
            scenarios = []
            for row in result:
                scenario = ScenarioSearchResult(
                    description_zh=row.description_zh,
                    description_en=row.description_en,
                    semantic_id=row.semantic_id,
                    variant_type=row.variant_type,
                    similarity_score=float(row.similarity_score)
                )
                scenarios.append(scenario)
            
            return scenarios
            
        except Exception as e:
            import traceback
            error_detail = f"搜索Clinical Scenarios失败: {str(e)}\n{traceback.format_exc()}"
            print(f"Vector search error: {error_detail}")  # 添加调试日志
            raise HTTPException(status_code=500, detail=f"搜索Clinical Scenarios失败: {str(e)}")
    
    def search_recommendations(
        self, 
        query_text: str, 
        top_k: int = 10, 
        similarity_threshold: float = 0.0
    ) -> List[RecommendationSearchResult]:
        """搜索相似的Clinical Recommendations"""
        start_time = time.time()
        
        try:
            # 生成查询向量
            query_vector = self._generate_query_vector(query_text)
            if query_vector is None:
                raise HTTPException(status_code=500, detail="无法生成查询向量")
            
            # 执行向量相似度搜索
            vector_str = '[' + ','.join(map(str, query_vector)) + ']'
            query = text(f"""
                    SELECT
                        cr.semantic_id,
                        pd.name_zh as procedure_name_zh,
                        pd.name_en as procedure_name_en,
                        pd.modality as procedure_modality,
                        pd.body_part as procedure_body_part,
                        cr.appropriateness_rating,
                        cr.appropriateness_category_zh,
                        cr.reasoning_zh,
                        cr.evidence_level,
                        cr.median_rating,
                        cr.adult_radiation_dose,
                        cr.pediatric_radiation_dose,
                        cr.pregnancy_safety,
                        cs.description_zh as scenario_description,
                        (1 - (cr.embedding <=> '{vector_str}'::vector)) as similarity_score
                    FROM clinical_recommendations cr
                    LEFT JOIN procedure_dictionary pd ON cr.procedure_id::integer = pd.id
                    LEFT JOIN clinical_scenarios cs ON cr.scenario_id = cs.semantic_id
                    WHERE cr.embedding IS NOT NULL
                    AND (1 - (cr.embedding <=> '{vector_str}'::vector)) >= {similarity_threshold}
                    ORDER BY cr.embedding <=> '{vector_str}'::vector
                    LIMIT {top_k}
                """)
            
            result = self.db.execute(query)
            
            recommendations = []
            for row in result:
                recommendation = RecommendationSearchResult(
                    semantic_id=row.semantic_id,
                    procedure_name_zh=row.procedure_name_zh or "",
                    procedure_name_en=row.procedure_name_en or "",
                    procedure_modality=row.procedure_modality,
                    procedure_body_part=row.procedure_body_part,
                    appropriateness_rating=row.appropriateness_rating,
                    appropriateness_category_zh=row.appropriateness_category_zh,
                    reasoning_zh=row.reasoning_zh,
                    evidence_level=row.evidence_level,
                    median_rating=float(row.median_rating) if row.median_rating else None,
                    adult_radiation_dose=row.adult_radiation_dose,
                    pediatric_radiation_dose=row.pediatric_radiation_dose,
                    pregnancy_safety=row.pregnancy_safety,
                    similarity_score=float(row.similarity_score),
                    scenario_description=row.scenario_description
                )
                recommendations.append(recommendation)
            
            return recommendations
            
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"搜索Clinical Recommendations失败: {str(e)}")
    
    def _generate_query_vector(self, query_text: str) -> List[float]:
        """生成查询向量"""
        try:
            # 使用Ollama BGE-M3模型生成向量
            response = requests.post(
                "http://localhost:11434/api/embeddings",
                json={
                    "model": "bge-m3:latest",
                    "prompt": query_text
                },
                timeout=30
            )
            
            if response.status_code == 200:
                result = response.json()
                vector = result.get("embedding", [])
                # 直接返回原始向量，不进行标准化
                return vector
            else:
                raise Exception(f"向量生成API错误: {response.status_code}")
                
        except Exception as e:
            logger.error(f"向量生成失败: {e}")
            # 降级到随机向量
            return np.random.rand(1024).tolist()

# ==================== API端点 ====================

def get_vector_search_service(db: Session = Depends(get_db)) -> VectorSearchService:
    """获取向量搜索服务"""
    return VectorSearchService(db)

@router.post("/search", response_model=VectorSearchResponse)
async def vector_search(
    request: VectorSearchRequest,
    service: VectorSearchService = Depends(get_vector_search_service)
):
    """
    向量相似度搜索
    
    根据患者主诉文本，搜索相似的Clinical Scenarios和Recommendations
    """
    start_time = time.time()
    
    try:
        # 搜索Clinical Scenarios
        scenarios = service.search_scenarios(
            query_text=request.query_text,
            top_k=request.top_k,
            similarity_threshold=request.similarity_threshold
        )
        
        # 搜索Clinical Recommendations
        recommendations = service.search_recommendations(
            query_text=request.query_text,
            top_k=request.top_k,
            similarity_threshold=request.similarity_threshold
        )
        
        search_time_ms = int((time.time() - start_time) * 1000)
        
        return VectorSearchResponse(
            query_text=request.query_text,
            search_time_ms=search_time_ms,
            scenarios=scenarios,
            recommendations=recommendations,
            total_scenarios_found=len(scenarios),
            total_recommendations_found=len(recommendations)
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"向量搜索失败: {str(e)}")

@router.post("/search/scenarios", response_model=List[ScenarioSearchResult])
async def search_scenarios_only(
    request: VectorSearchRequest,
    service: VectorSearchService = Depends(get_vector_search_service)
):
    """
    仅搜索Clinical Scenarios
    
    根据患者主诉文本，搜索相似的Clinical Scenarios
    """
    try:
        scenarios = service.search_scenarios(
            query_text=request.query_text,
            top_k=request.top_k,
            similarity_threshold=request.similarity_threshold
        )
        return scenarios
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"搜索Clinical Scenarios失败: {str(e)}")

@router.post("/search/recommendations", response_model=List[RecommendationSearchResult])
async def search_recommendations_only(
    request: VectorSearchRequest,
    service: VectorSearchService = Depends(get_vector_search_service)
):
    """
    仅搜索Clinical Recommendations
    
    根据患者主诉文本，搜索相似的Clinical Recommendations
    """
    try:
        recommendations = service.search_recommendations(
            query_text=request.query_text,
            top_k=request.top_k,
            similarity_threshold=request.similarity_threshold
        )
        return recommendations
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"搜索Clinical Recommendations失败: {str(e)}")

@router.get("/health")
async def health_check(service: VectorSearchService = Depends(get_vector_search_service)):
    """健康检查"""
    return {
        "status": "healthy",
        "service": "vector_search",
        "message": "向量搜索服务运行正常"
    }
