"""
ACRAC API端点 - 完整的数据管理和智能搜索API
"""
from typing import List, Optional, Dict, Any
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.services.acrac_service import ACRACService
from app.schemas.acrac_schemas import (
    PanelCreate, PanelUpdate, PanelResponse,
    TopicCreate, TopicUpdate, TopicResponse,
    ClinicalScenarioCreate, ClinicalScenarioUpdate, ClinicalScenarioResponse,
    ProcedureDictionaryCreate, ProcedureDictionaryUpdate, ProcedureDictionaryResponse,
    ClinicalRecommendationCreate, ClinicalRecommendationUpdate, ClinicalRecommendationResponse,
    RecommendationWithDetails,
    VectorSearchRequest, VectorSearchResponse,
    IntelligentRecommendationRequest, IntelligentRecommendationResponse,
    DataStatistics, HealthCheckResponse,
    PaginatedPanels, PaginatedTopics, PaginatedScenarios, PaginatedProcedures, PaginatedRecommendations
)

router = APIRouter()

# 依赖注入
def get_acrac_service(db: Session = Depends(get_db)) -> ACRACService:
    return ACRACService(db)

# ==================== 健康检查和统计 ====================

@router.get("/health", response_model=HealthCheckResponse)
def health_check(service: ACRACService = Depends(get_acrac_service)):
    """系统健康检查"""
    return service.health_check()

@router.get("/statistics", response_model=DataStatistics)
def get_statistics(service: ACRACService = Depends(get_acrac_service)):
    """获取系统统计信息"""
    return service.get_statistics()

# ==================== Panel 管理 ====================

@router.post("/panels", response_model=PanelResponse, status_code=status.HTTP_201_CREATED)
def create_panel(
    panel: PanelCreate,
    service: ACRACService = Depends(get_acrac_service)
):
    """创建Panel"""
    try:
        return service.create_panel(panel)
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"创建Panel失败: {str(e)}")

@router.get("/panels/{semantic_id}", response_model=PanelResponse)
def get_panel(
    semantic_id: str,
    service: ACRACService = Depends(get_acrac_service)
):
    """获取Panel详情"""
    panel = service.get_panel(semantic_id)
    if not panel:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Panel不存在")
    return panel

@router.get("/panels", response_model=PaginatedPanels)
def list_panels(
    active_only: bool = Query(True, description="只显示激活的Panel"),
    page: int = Query(1, ge=1, description="页码"),
    page_size: int = Query(50, ge=1, le=100, description="每页大小"),
    service: ACRACService = Depends(get_acrac_service)
):
    """列出所有Panels"""
    panels, total = service.list_panels(active_only, page, page_size)
    
    total_pages = (total + page_size - 1) // page_size
    
    return PaginatedPanels(
        total=total,
        page=page,
        page_size=page_size,
        total_pages=total_pages,
        has_next=page < total_pages,
        has_prev=page > 1,
        items=panels
    )

@router.put("/panels/{semantic_id}", response_model=PanelResponse)
def update_panel(
    semantic_id: str,
    panel_update: PanelUpdate,
    service: ACRACService = Depends(get_acrac_service)
):
    """更新Panel"""
    try:
        panel = service.update_panel(semantic_id, panel_update)
        if not panel:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Panel不存在")
        return panel
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=f"更新Panel失败: {str(e)}")

@router.delete("/panels/{semantic_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_panel(
    semantic_id: str,
    service: ACRACService = Depends(get_acrac_service)
):
    """删除Panel（级联删除相关数据）"""
    success = service.delete_panel(semantic_id)
    if not success:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Panel不存在")

# ==================== Topic 管理 ====================

@router.post("/topics", response_model=TopicResponse, status_code=status.HTTP_201_CREATED)
def create_topic(
    topic: TopicCreate,
    service: ACRACService = Depends(get_acrac_service)
):
    """创建Topic"""
    try:
        return service.create_topic(topic)
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"创建Topic失败: {str(e)}")

@router.get("/panels/{panel_semantic_id}/topics", response_model=List[TopicResponse])
def get_topics_by_panel(
    panel_semantic_id: str,
    active_only: bool = Query(True, description="只显示激活的Topic"),
    service: ACRACService = Depends(get_acrac_service)
):
    """获取Panel下的所有Topics"""
    return service.get_topics_by_panel(panel_semantic_id, active_only)

# ==================== Clinical Scenario 管理 ====================

@router.post("/scenarios", response_model=ClinicalScenarioResponse, status_code=status.HTTP_201_CREATED)
def create_scenario(
    scenario: ClinicalScenarioCreate,
    service: ACRACService = Depends(get_acrac_service)
):
    """创建Clinical Scenario"""
    try:
        return service.create_scenario(scenario)
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"创建Scenario失败: {str(e)}")

@router.get("/topics/{topic_semantic_id}/scenarios", response_model=List[ClinicalScenarioResponse])
def get_scenarios_by_topic(
    topic_semantic_id: str,
    active_only: bool = Query(True, description="只显示激活的Scenario"),
    service: ACRACService = Depends(get_acrac_service)
):
    """获取Topic下的所有Scenarios"""
    return service.get_scenarios_by_topic(topic_semantic_id, active_only)

# ==================== Procedure Dictionary 管理 ====================

@router.post("/procedures", response_model=ProcedureDictionaryResponse, status_code=status.HTTP_201_CREATED)
def create_procedure(
    procedure: ProcedureDictionaryCreate,
    service: ACRACService = Depends(get_acrac_service)
):
    """创建检查项目"""
    try:
        return service.create_procedure(procedure)
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"创建检查项目失败: {str(e)}")

@router.get("/procedures", response_model=List[ProcedureDictionaryResponse])
def search_procedures(
    modality: Optional[str] = Query(None, description="检查方式"),
    body_part: Optional[str] = Query(None, description="检查部位"),
    contrast_used: Optional[bool] = Query(None, description="是否使用对比剂"),
    active_only: bool = Query(True, description="只显示激活的检查项目"),
    service: ACRACService = Depends(get_acrac_service)
):
    """搜索检查项目"""
    return service.search_procedures(modality, body_part, contrast_used, active_only)

# ==================== Clinical Recommendation 管理 ====================

@router.post("/recommendations", response_model=ClinicalRecommendationResponse, status_code=status.HTTP_201_CREATED)
def create_recommendation(
    recommendation: ClinicalRecommendationCreate,
    service: ACRACService = Depends(get_acrac_service)
):
    """创建临床推荐"""
    try:
        return service.create_recommendation(recommendation)
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"创建推荐失败: {str(e)}")

@router.get("/scenarios/{scenario_id}/recommendations", response_model=List[RecommendationWithDetails])
def get_recommendations_for_scenario(
    scenario_id: str,
    min_rating: Optional[int] = Query(None, ge=1, le=9, description="最低适宜性评分"),
    service: ACRACService = Depends(get_acrac_service)
):
    """获取场景的所有推荐"""
    return service.get_recommendations_for_scenario(scenario_id, min_rating)

@router.get("/procedures/{procedure_id}/recommendations", response_model=List[RecommendationWithDetails])
def get_recommendations_for_procedure(
    procedure_id: str,
    min_rating: Optional[int] = Query(None, ge=1, le=9, description="最低适宜性评分"),
    service: ACRACService = Depends(get_acrac_service)
):
    """获取检查项目的所有推荐场景"""
    return service.get_recommendations_for_procedure(procedure_id, min_rating)

# ==================== 智能搜索功能 ====================

@router.post("/search/vector", response_model=VectorSearchResponse)
def vector_search(
    request: VectorSearchRequest,
    service: ACRACService = Depends(get_acrac_service)
):
    """向量搜索"""
    try:
        return service.vector_search(request)
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"向量搜索失败: {str(e)}")

@router.post("/search/intelligent", response_model=IntelligentRecommendationResponse)
def intelligent_recommendation(
    request: IntelligentRecommendationRequest,
    service: ACRACService = Depends(get_acrac_service)
):
    """智能推荐搜索"""
    try:
        return service.intelligent_recommendation(request)
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"智能推荐失败: {str(e)}")

@router.get("/search/similar-scenarios/{scenario_id}", response_model=List[ClinicalScenarioResponse])
def find_similar_scenarios(
    scenario_id: str,
    similarity_threshold: float = Query(0.8, ge=0.0, le=1.0, description="相似度阈值"),
    limit: int = Query(10, ge=1, le=50, description="返回结果数量"),
    service: ACRACService = Depends(get_acrac_service)
):
    """查找相似的临床场景"""
    try:
        # 获取目标场景的向量
        scenario = service.db.query(service.db.query(ClinicalScenario).filter(
            ClinicalScenario.semantic_id == scenario_id
        ).first())
        
        if not scenario or not scenario.embedding:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="场景不存在或无向量嵌入")
        
        # 向量搜索
        search_request = VectorSearchRequest(
            query_text="",  # 直接使用向量搜索
            table_name="scenarios",
            limit=limit + 1,  # +1是为了排除自己
            similarity_threshold=similarity_threshold
        )
        
        # 这里需要实现基于已有向量的搜索
        # 简化实现，实际需要更复杂的逻辑
        return []
        
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"查找相似场景失败: {str(e)}")

# ==================== 快捷查询API ====================

@router.get("/quick/high-rating-recommendations", response_model=List[RecommendationWithDetails])
def get_high_rating_recommendations(
    min_rating: int = Query(8, ge=1, le=9, description="最低评分"),
    limit: int = Query(20, ge=1, le=100, description="返回数量"),
    service: ACRACService = Depends(get_acrac_service)
):
    """获取高评分推荐"""
    try:
        # 查询高评分推荐
        recommendations = service.db.query(ClinicalRecommendation).filter(
            and_(
                ClinicalRecommendation.appropriateness_rating >= min_rating,
                ClinicalRecommendation.is_active == True
            )
        ).order_by(ClinicalRecommendation.appropriateness_rating.desc()).limit(limit).all()
        
        return [service._build_recommendation_with_details(rec) for rec in recommendations]
        
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"查询失败: {str(e)}")

@router.get("/quick/procedures-by-modality/{modality}", response_model=List[ProcedureDictionaryResponse])
def get_procedures_by_modality(
    modality: str,
    service: ACRACService = Depends(get_acrac_service)
):
    """按检查方式获取检查项目"""
    return service.search_procedures(modality=modality, active_only=True)

@router.get("/quick/pregnancy-safe-recommendations", response_model=List[RecommendationWithDetails])
def get_pregnancy_safe_recommendations(
    limit: int = Query(20, ge=1, le=100, description="返回数量"),
    service: ACRACService = Depends(get_acrac_service)
):
    """获取妊娠安全的推荐"""
    try:
        recommendations = service.db.query(ClinicalRecommendation).filter(
            and_(
                ClinicalRecommendation.pregnancy_safety == '安全',
                ClinicalRecommendation.is_active == True
            )
        ).order_by(ClinicalRecommendation.appropriateness_rating.desc()).limit(limit).all()
        
        return [service._build_recommendation_with_details(rec) for rec in recommendations]
        
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"查询失败: {str(e)}")

# ==================== 数据分析API ====================

@router.get("/analytics/modality-distribution", response_model=Dict[str, int])
def get_modality_distribution(service: ACRACService = Depends(get_acrac_service)):
    """获取检查方式分布"""
    try:
        result = service.db.execute(text("""
            SELECT modality, COUNT(*) as count
            FROM procedure_dictionary 
            WHERE is_active = TRUE AND modality IS NOT NULL
            GROUP BY modality 
            ORDER BY count DESC;
        """))
        
        return {row[0]: row[1] for row in result}
        
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"分析失败: {str(e)}")

@router.get("/analytics/rating-distribution", response_model=Dict[str, int])
def get_rating_distribution(service: ACRACService = Depends(get_acrac_service)):
    """获取适宜性评分分布"""
    try:
        result = service.db.execute(text("""
            SELECT appropriateness_rating, COUNT(*) as count
            FROM clinical_recommendations 
            WHERE is_active = TRUE AND appropriateness_rating IS NOT NULL
            GROUP BY appropriateness_rating 
            ORDER BY appropriateness_rating;
        """))
        
        return {f"{row[0]}分": row[1] for row in result}
        
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"分析失败: {str(e)}")

@router.get("/analytics/patient-population-stats", response_model=Dict[str, int])
def get_patient_population_stats(service: ACRACService = Depends(get_acrac_service)):
    """获取患者人群统计"""
    try:
        result = service.db.execute(text("""
            SELECT patient_population, COUNT(*) as count
            FROM clinical_scenarios 
            WHERE is_active = TRUE AND patient_population IS NOT NULL
            GROUP BY patient_population 
            ORDER BY count DESC;
        """))
        
        return {row[0]: row[1] for row in result}
        
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"分析失败: {str(e)}")

# ==================== 高级查询API ====================

@router.get("/advanced/recommendations-by-criteria")
def get_recommendations_by_criteria(
    panel_id: Optional[str] = Query(None, description="Panel ID"),
    topic_id: Optional[str] = Query(None, description="Topic ID"),
    modality: Optional[str] = Query(None, description="检查方式"),
    patient_population: Optional[str] = Query(None, description="患者人群"),
    min_rating: Optional[int] = Query(None, ge=1, le=9, description="最低评分"),
    pregnancy_safe: Optional[bool] = Query(None, description="妊娠安全"),
    limit: int = Query(50, ge=1, le=200, description="返回数量"),
    service: ACRACService = Depends(get_acrac_service)
):
    """按多重条件查询推荐"""
    try:
        # 构建动态查询
        sql = """
            SELECT 
                cr.semantic_id, cr.appropriateness_rating, cr.reasoning_zh,
                s.semantic_id as scenario_sid, s.description_zh as scenario_desc,
                s.patient_population, s.risk_level, s.age_group,
                pd.semantic_id as procedure_sid, pd.name_zh as procedure_name,
                pd.modality, pd.body_part, pd.radiation_level,
                p.name_zh as panel_name, t.name_zh as topic_name
            FROM clinical_recommendations cr
            JOIN clinical_scenarios s ON cr.scenario_id = s.semantic_id
            JOIN procedure_dictionary pd ON cr.procedure_id = pd.semantic_id
            JOIN topics t ON s.topic_id = t.id
            JOIN panels p ON s.panel_id = p.id
            WHERE cr.is_active = TRUE
        """
        
        params = {}
        
        if panel_id:
            sql += " AND p.semantic_id = :panel_id"
            params['panel_id'] = panel_id
        
        if topic_id:
            sql += " AND t.semantic_id = :topic_id"
            params['topic_id'] = topic_id
        
        if modality:
            sql += " AND pd.modality = :modality"
            params['modality'] = modality
        
        if patient_population:
            sql += " AND s.patient_population = :patient_population"
            params['patient_population'] = patient_population
        
        if min_rating:
            sql += " AND cr.appropriateness_rating >= :min_rating"
            params['min_rating'] = min_rating
        
        if pregnancy_safe:
            sql += " AND cr.pregnancy_safety = '安全'"
        
        sql += " ORDER BY cr.appropriateness_rating DESC, cr.semantic_id LIMIT :limit"
        params['limit'] = limit
        
        result = service.db.execute(text(sql), params)
        
        recommendations = []
        for row in result:
            recommendations.append({
                'recommendation_id': row[0],
                'rating': row[1],
                'reasoning': row[2],
                'scenario': {
                    'id': row[3],
                    'description': row[4],
                    'patient_population': row[5],
                    'risk_level': row[6],
                    'age_group': row[7]
                },
                'procedure': {
                    'id': row[8],
                    'name': row[9],
                    'modality': row[10],
                    'body_part': row[11],
                    'radiation_level': row[12]
                },
                'panel_name': row[13],
                'topic_name': row[14]
            })
        
        return {
            'total_found': len(recommendations),
            'recommendations': recommendations,
            'query_params': params
        }
        
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"查询失败: {str(e)}")

# ==================== 数据导出API ====================

@router.get("/export/recommendations-summary")
def export_recommendations_summary(
    format: str = Query("json", description="导出格式: json, csv"),
    service: ACRACService = Depends(get_acrac_service)
):
    """导出推荐摘要"""
    try:
        result = service.db.execute(text("""
            SELECT 
                p.name_zh as panel_name,
                t.name_zh as topic_name,
                COUNT(DISTINCT s.semantic_id) as scenarios_count,
                COUNT(DISTINCT pd.semantic_id) as procedures_count,
                COUNT(cr.semantic_id) as recommendations_count,
                ROUND(AVG(cr.appropriateness_rating), 2) as avg_rating
            FROM clinical_recommendations cr
            JOIN clinical_scenarios s ON cr.scenario_id = s.semantic_id
            JOIN procedure_dictionary pd ON cr.procedure_id = pd.semantic_id
            JOIN topics t ON s.topic_id = t.id
            JOIN panels p ON s.panel_id = p.id
            WHERE cr.is_active = TRUE
            GROUP BY p.semantic_id, p.name_zh, t.semantic_id, t.name_zh
            ORDER BY p.name_zh, t.name_zh;
        """))
        
        summary = []
        for row in result:
            summary.append({
                'panel_name': row[0],
                'topic_name': row[1],
                'scenarios_count': row[2],
                'procedures_count': row[3],
                'recommendations_count': row[4],
                'average_rating': float(row[5]) if row[5] else None
            })
        
        return {
            'export_time': datetime.utcnow().isoformat(),
            'total_items': len(summary),
            'format': format,
            'data': summary
        }
        
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"导出失败: {str(e)}")
